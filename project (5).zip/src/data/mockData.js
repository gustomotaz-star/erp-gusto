export const taxOptions = [
  { value: '0', label: 'بدون ضريبة' },
  { value: '5', label: '5%' },
  { value: '10', label: '10%' }
]

export const statusOptions = [
  { value: 'active', label: 'نشط' },
  { value: 'inactive', label: 'غير نشط' }
]

export const paymentTypeOptions = [
  { value: 'cash', label: 'نقدي' },
  { value: 'credit', label: 'آجل' }
]

export const paymentMethodOptions = [
  { value: 'cash', label: 'نقدي' },
  { value: 'bank', label: 'تحويل بنكي' },
  { value: 'check', label: 'شيك' },
  { value: 'card', label: 'بطاقة' }
]

export const invoiceStatusOptions = [
  { value: 'paid', label: 'مدفوع' },
  { value: 'partial', label: 'مدفوع جزئياً' },
  { value: 'unpaid', label: 'غير مدفوع' }
]