import { useState, useEffect } from 'react'
import { Search } from 'lucide-react'
import { motion } from 'framer-motion'
import { storage } from '../utils/storage'
import { formatCurrency } from '../utils/calculations'

const Payments = () => {
  const [payments, setPayments] = useState([])
  const [invoices, setInvoices] = useState([])
  const [searchTerm, setSearchTerm] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = () => {
    try {
      setLoading(true)
      const paymentsData = storage.get('PAYMENTS') || []
      const invoicesData = storage.get('INVOICES') || []
      setPayments(Array.isArray(paymentsData) ? paymentsData : [])
      setInvoices(Array.isArray(invoicesData) ? invoicesData : [])
    } catch (error) {
      console.error('Error loading data:', error)
      setPayments([])
      setInvoices([])
    } finally {
      setLoading(false)
    }
  }

  const getInvoiceNumber = (invoiceId) => {
    if (!Array.isArray(invoices)) return '-'
    const invoice = invoices.find(inv => inv.id === invoiceId)
    return invoice?.invoice_number || '-'
  }

  const getPaymentMethodLabel = (method) => {
    const labels = {
      cash: 'نقدي',
      bank: 'تحويل بنكي',
      check: 'شيك',
      card: 'بطاقة'
    }
    return labels[method] || method
  }

  const filteredPayments = []
  if (Array.isArray(payments)) {
    for (let i = 0; i < payments.length; i++) {
      const payment = payments[i]
      const invoiceNumber = getInvoiceNumber(payment.invoice_id)
      if (invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
          payment.payment_date?.includes(searchTerm)) {
        filteredPayments.push(payment)
      }
    }
  }

  let totalPayments = 0
  if (Array.isArray(filteredPayments)) {
    for (let i = 0; i < filteredPayments.length; i++) {
      totalPayments += (filteredPayments[i].amount || 0)
    }
  }

  const renderPaymentRows = () => {
    const rows = []
    for (let i = 0; i < filteredPayments.length; i++) {
      const payment = filteredPayments[i]
      rows.push(
        <motion.tr
          key={payment.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.05 }}
          className="border-b hover:bg-gray-50"
        >
          <td className="py-4 px-6 font-semibold">{getInvoiceNumber(payment.invoice_id)}</td>
          <td className="py-4 px-6">{payment.payment_date}</td>
          <td className="py-4 px-6 font-bold text-success">{formatCurrency(payment.amount)}</td>
          <td className="py-4 px-6">
            <span className="px-3 py-1 rounded-full text-sm bg-primary/20 text-primary">
              {getPaymentMethodLabel(payment.payment_method)}
            </span>
          </td>
          <td className="py-4 px-6 text-gray-600">{payment.notes || '-'}</td>
        </motion.tr>
      )
    }
    return rows
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-dark">المدفوعات</h1>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="بحث برقم الفاتورة أو التاريخ..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pr-10 pl-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          <div className="flex items-center justify-end">
            <div className="text-left">
              <p className="text-sm text-gray-600">إجمالي المدفوعات</p>
              <p className="text-2xl font-bold text-success">{formatCurrency(totalPayments)}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="text-right py-4 px-6 font-semibold">رقم الفاتورة</th>
                <th className="text-right py-4 px-6 font-semibold">تاريخ الدفع</th>
                <th className="text-right py-4 px-6 font-semibold">المبلغ</th>
                <th className="text-right py-4 px-6 font-semibold">طريقة الدفع</th>
                <th className="text-right py-4 px-6 font-semibold">ملاحظات</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="5" className="py-12 text-center text-gray-500">
                    جاري التحميل...
                  </td>
                </tr>
              ) : filteredPayments.length > 0 ? (
                renderPaymentRows()
              ) : (
                <tr>
                  <td colSpan="5" className="py-12 text-center text-gray-500">
                    لا توجد مدفوعات
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

export default Payments