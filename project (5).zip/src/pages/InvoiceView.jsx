import { useState, useEffect } from 'react'
import { useNavigate, useParams, Link } from 'react-router-dom'
import { ArrowRight, Plus, Printer } from 'lucide-react'
import { storage } from '../utils/storage'
import { formatCurrency } from '../utils/calculations'
import Button from '../components/Button'

const InvoiceView = () => {
  const navigate = useNavigate()
  const { id } = useParams()
  const [invoice, setInvoice] = useState(null)
  const [customer, setCustomer] = useState(null)
  const [items, setItems] = useState([])
  const [payments, setPayments] = useState([])

  useEffect(() => {
    loadInvoiceData()
  }, [id])

  const loadInvoiceData = () => {
    const invoiceData = storage.getById('INVOICES', id)
    if (invoiceData) {
      setInvoice(invoiceData)
      const customerData = storage.getById('CUSTOMERS', invoiceData.customer_id)
      setCustomer(customerData)
      const itemsData = storage.get('INVOICE_ITEMS').filter(item => item.invoice_id === id)
      setItems(itemsData)
      const paymentsData = storage.get('PAYMENTS').filter(payment => payment.invoice_id === id)
      setPayments(paymentsData)
    }
  }

  const handlePrint = () => {
    window.print()
  }

  if (!invoice) {
    return <div className="text-center py-12">جاري التحميل...</div>
  }

  const remaining = invoice.final_total - (invoice.paid_amount || 0)

  return (
    <div>
      <div className="flex items-center justify-between mb-6 print:hidden">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/invoices')} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <ArrowRight size={24} />
          </button>
          <h1 className="text-3xl font-bold text-dark">عرض الفاتورة</h1>
        </div>
        <div className="flex gap-3">
          {remaining > 0 && (
            <Link to={`/payments/new/${invoice.id}`}>
              <Button variant="success">
                <Plus size={20} className="ml-2" />
                إضافة دفعة
              </Button>
            </Link>
          )}
          <Button onClick={handlePrint} variant="outline">
            <Printer size={20} className="ml-2" />
            طباعة
          </Button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-8 mb-6">
        <div className="flex justify-between items-start mb-8">
          <div>
            <h2 className="text-2xl font-bold text-primary mb-2">فاتورة مبيعات</h2>
            <p className="text-gray-600">رقم الفاتورة: {invoice.invoice_number}</p>
            <p className="text-gray-600">التاريخ: {invoice.invoice_date}</p>
            {invoice.payment_type === 'credit' && invoice.due_date && (
              <p className="text-gray-600">تاريخ الاستحقاق: {invoice.due_date}</p>
            )}
          </div>
          <div className="text-left">
            <h3 className="font-bold mb-2">معلومات العميل</h3>
            <p className="text-gray-600">{customer?.customer_name}</p>
            <p className="text-gray-600">{customer?.phone}</p>
            {customer?.email && <p className="text-gray-600">{customer.email}</p>}
            {customer?.address && <p className="text-gray-600">{customer.address}</p>}
            {customer?.tax_number && <p className="text-gray-600">الرقم الضريبي: {customer.tax_number}</p>}
          </div>
        </div>

        <div className="overflow-x-auto mb-6">
          <table className="w-full">
            <thead className="bg-gray-50 border-b-2">
              <tr>
                <th className="text-right py-3 px-4 font-semibold">#</th>
                <th className="text-right py-3 px-4 font-semibold">الوصف</th>
                <th className="text-right py-3 px-4 font-semibold">السعر</th>
                <th className="text-right py-3 px-4 font-semibold">الكمية</th>
                <th className="text-right py-3 px-4 font-semibold">الخصم</th>
                <th className="text-right py-3 px-4 font-semibold">الضريبة</th>
                <th className="text-right py-3 px-4 font-semibold">الإجمالي</th>
              </tr>
            </thead>
            <tbody>
              {items.map((item, index) => (
                <tr key={item.id} className="border-b">
                  <td className="py-3 px-4">{index + 1}</td>
                  <td className="py-3 px-4">{item.description}</td>
                  <td className="py-3 px-4">{formatCurrency(item.unit_price)}</td>
                  <td className="py-3 px-4">{item.quantity}</td>
                  <td className="py-3 px-4">{item.discount_percent}%</td>
                  <td className="py-3 px-4">{item.tax1 + item.tax2}%</td>
                  <td className="py-3 px-4 font-semibold">{formatCurrency(item.line_total)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex justify-end">
          <div className="w-full max-w-md">
            <div className="flex justify-between py-2 border-b">
              <span>الإجمالي قبل الخصم:</span>
              <span className="font-semibold">{formatCurrency(invoice.total_before_discount)}</span>
            </div>
            {invoice.invoice_discount > 0 && (
              <div className="flex justify-between py-2 border-b">
                <span>خصم الفاتورة ({invoice.invoice_discount}%):</span>
                <span className="font-semibold text-danger">-{formatCurrency(invoice.total_before_discount * (invoice.invoice_discount / 100))}</span>
              </div>
            )}
            <div className="flex justify-between py-2 border-b">
              <span>الضرائب:</span>
              <span className="font-semibold">{formatCurrency(invoice.tax_total)}</span>
            </div>
            <div className="flex justify-between py-3 text-xl font-bold border-t-2">
              <span>الإجمالي النهائي:</span>
              <span className="text-primary">{formatCurrency(invoice.final_total)}</span>
            </div>
          </div>
        </div>

        {invoice.notes && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-bold mb-2">ملاحظات:</h3>
            <p className="text-gray-600">{invoice.notes}</p>
          </div>
        )}
      </div>

      {payments.length > 0 && (
        <div className="bg-white rounded-lg shadow-md p-6 mb-6 print:hidden">
          <h2 className="text-xl font-bold mb-4">سجل الدفعات</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="text-right py-3 px-4 font-semibold">التاريخ</th>
                  <th className="text-right py-3 px-4 font-semibold">المبلغ</th>
                  <th className="text-right py-3 px-4 font-semibold">طريقة الدفع</th>
                  <th className="text-right py-3 px-4 font-semibold">ملاحظات</th>
                </tr>
              </thead>
              <tbody>
                {payments.map((payment) => (
                  <tr key={payment.id} className="border-b">
                    <td className="py-3 px-4">{payment.payment_date}</td>
                    <td className="py-3 px-4 font-semibold text-success">{formatCurrency(payment.amount)}</td>
                    <td className="py-3 px-4">{payment.payment_method === 'cash' ? 'نقدي' : payment.payment_method === 'bank' ? 'تحويل بنكي' : payment.payment_method === 'check' ? 'شيك' : 'بطاقة'}</td>
                    <td className="py-3 px-4">{payment.notes || '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-4 flex justify-end">
            <div className="w-full max-w-md">
              <div className="flex justify-between py-2">
                <span>إجمالي المدفوع:</span>
                <span className="font-semibold text-success">{formatCurrency(invoice.paid_amount)}</span>
              </div>
              <div className="flex justify-between py-2 border-t-2">
                <span className="font-bold">المتبقي:</span>
                <span className={`font-bold ${remaining > 0 ? 'text-danger' : 'text-success'}`}>
                  {formatCurrency(remaining)}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default InvoiceView