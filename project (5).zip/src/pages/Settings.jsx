import { useState } from 'react'
import { motion } from 'framer-motion'
import { Save, User, Bell, Settings as SettingsIcon, Database, Palette, Download, Upload, Trash2, RefreshCw } from 'lucide-react'
import Button from '../components/Button'
import Input from '../components/Input'
import Select from '../components/Select'
import Modal from '../components/Modal'
import { saveToStorage, getFromStorage, clearAllData, exportData, importData } from '../utils/storage'

const Settings = () => {

  // ✅ التعديل الوحيد لحل مشكلة map
  const safe = (arr) => Array.isArray(arr) ? arr : [];

  const [activeTab, setActiveTab] = useState('user')
  const [showBackupModal, setShowBackupModal] = useState(false)
  const [showRestoreModal, setShowRestoreModal] = useState(false)
  const [showClearModal, setShowClearModal] = useState(false)
  const [notification, setNotification] = useState({ show: false, message: '', type: '' })

  const [userSettings, setUserSettings] = useState({
    businessName: getFromStorage('businessName') || 'نظام المبيعات',
    email: getFromStorage('userEmail') || '',
    phone: getFromStorage('userPhone') || '',
    address: getFromStorage('userAddress') || ''
  })

  const [systemSettings, setSystemSettings] = useState({
    currency: getFromStorage('currency') || 'SAR',
    taxRate1: getFromStorage('taxRate1') || '15',
    taxRate2: getFromStorage('taxRate2') || '0',
    invoicePrefix: getFromStorage('invoicePrefix') || 'INV',
    lowStockThreshold: getFromStorage('lowStockThreshold') || '10'
  })

  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: getFromStorage('emailNotifications') !== 'false',
    lowStockAlerts: getFromStorage('lowStockAlerts') !== 'false',
    paymentReminders: getFromStorage('paymentReminders') !== 'false',
    invoiceAlerts: getFromStorage('invoiceAlerts') !== 'false'
  })

  const [appearanceSettings, setAppearanceSettings] = useState({
    theme: getFromStorage('theme') || 'light',
    language: getFromStorage('language') || 'ar',
    dateFormat: getFromStorage('dateFormat') || 'DD/MM/YYYY',
    numberFormat: getFromStorage('numberFormat') || 'en'
  })

  const showNotification = (message, type = 'success') => {
    setNotification({ show: true, message, type })
    setTimeout(() => setNotification({ show: false, message: '', type: '' }), 3000)
  }

  const handleSaveUserSettings = () => {
    saveToStorage('businessName', userSettings.businessName)
    saveToStorage('userEmail', userSettings.email)
    saveToStorage('userPhone', userSettings.phone)
    saveToStorage('userAddress', userSettings.address)
    showNotification('تم حفظ إعدادات المستخدم بنجاح')
  }

  const handleSaveSystemSettings = () => {
    saveToStorage('currency', systemSettings.currency)
    saveToStorage('taxRate1', systemSettings.taxRate1)
    saveToStorage('taxRate2', systemSettings.taxRate2)
    saveToStorage('invoicePrefix', systemSettings.invoicePrefix)
    saveToStorage('lowStockThreshold', systemSettings.lowStockThreshold)
    showNotification('تم حفظ إعدادات النظام بنجاح')
  }

  const handleSaveNotifications = () => {
    saveToStorage('emailNotifications', notificationSettings.emailNotifications)
    saveToStorage('lowStockAlerts', notificationSettings.lowStockAlerts)
    saveToStorage('paymentReminders', notificationSettings.paymentReminders)
    saveToStorage('invoiceAlerts', notificationSettings.invoiceAlerts)
    showNotification('تم حفظ إعدادات الإشعارات بنجاح')
  }

  const handleSaveAppearance = () => {
    saveToStorage('theme', appearanceSettings.theme)
    saveToStorage('language', appearanceSettings.language)
    saveToStorage('dateFormat', appearanceSettings.dateFormat)
    saveToStorage('numberFormat', appearanceSettings.numberFormat)
    showNotification('تم حفظ إعدادات المظهر بنجاح')
  }

  const handleExportData = () => {
    const data = exportData()
    const blob = new Blob([data], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `backup_${new Date().toISOString().split('T')[0]}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    showNotification('تم تصدير البيانات بنجاح')
    setShowBackupModal(false)
  }

  const handleImportData = (event) => {
    const file = event.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        try {
          const data = e.target.result
          importData(data)
          showNotification('تم استيراد البيانات بنجاح')
          setShowRestoreModal(false)
          setTimeout(() => window.location.reload(), 1500)
        } catch (error) {
          showNotification('فشل استيراد البيانات', 'error')
        }
      }
      reader.readAsText(file)
    }
  }

  const handleClearAllData = () => {
    clearAllData()
    showNotification('تم مسح جميع البيانات بنجاح')
    setShowClearModal(false)
    setTimeout(() => window.location.reload(), 1500)
  }

  // ← نفس التابات الأصلية
  const tabs = [
    { id: 'user', label: 'الملف الشخصي', icon: User },
    { id: 'system', label: 'إعدادات النظام', icon: SettingsIcon },
    { id: 'notifications', label: 'الإشعارات', icon: Bell },
    { id: 'appearance', label: 'المظهر', icon: Palette },
    { id: 'data', label: 'إدارة البيانات', icon: Database }
  ]

  return (
    <div className="space-y-6">

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="border-b border-gray-200">
          <div className="flex overflow-x-auto">

            {/* ✅ التعديل الوحيد: safe(tabs).map بدل tabs.map */}
            {safe(tabs).map((tab) => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-6 py-4 font-semibold whitespace-nowrap transition-colors ${
                    activeTab === tab.id
                      ? 'text-primary border-b-2 border-primary bg-blue-50'
                      : 'text-gray-600 hover:text-primary hover:bg-gray-50'
                  }`}
                >
                  <Icon size={20} />
                  {tab.label}
                </button>
              )
            })}

          </div>
        </div>

        {/* 👇 كل كود الصفحات الداخلية كما هو بدون تغيير */}

        {/* الملف الشخصي */}
        {activeTab === 'user' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="p-6 space-y-6"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label="اسم المنشأة"
                value={userSettings.businessName}
                onChange={(e) => setUserSettings({ ...userSettings, businessName: e.target.value })}
              />
              <Input
                label="البريد الإلكتروني"
                type="email"
                value={userSettings.email}
                onChange={(e) => setUserSettings({ ...userSettings, email: e.target.value })}
              />
              <Input
                label="رقم الهاتف"
                value={userSettings.phone}
                onChange={(e) => setUserSettings({ ...userSettings, phone: e.target.value })}
              />
              <Input
                label="العنوان"
                value={userSettings.address}
                onChange={(e) => setUserSettings({ ...userSettings, address: e.target.value })}
              />
            </div>
            <div className="flex justify-end">
              <Button onClick={handleSaveUserSettings}>
                <Save size={20} />
                حفظ التغييرات
              </Button>
            </div>
          </motion.div>
        )}

        {/* إعدادات النظام */}
        {activeTab === 'system' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="p-6 space-y-6"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Select
                label="العملة"
                value={systemSettings.currency}
                onChange={(e) => setSystemSettings({ ...systemSettings, currency: e.target.value })}
                options={[
                  { value: 'SAR', label: 'ريال سعودي (SAR)' },
                  { value: 'USD', label: 'دولار أمريكي (USD)' },
                  { value: 'EUR', label: 'يورو (EUR)' }
                ]}
              />
              <Input
                label="نسبة الضريبة 1 (%)"
                type="number"
                value={systemSettings.taxRate1}
                onChange={(e) => setSystemSettings({ ...systemSettings, taxRate1: e.target.value })}
              />
              <Input
                label="نسبة الضريبة 2 (%)"
                type="number"
                value={systemSettings.taxRate2}
                onChange={(e) => setSystemSettings({ ...systemSettings, taxRate2: e.target.value })}
              />
              <Input
                label="بادئة رقم الفاتورة"
                value={systemSettings.invoicePrefix}
                onChange={(e) => setSystemSettings({ ...systemSettings, invoicePrefix: e.target.value })}
              />
              <Input
                label="حد تنبيه المخزون المنخفض"
                type="number"
                value={systemSettings.lowStockThreshold}
                onChange={(e) => setSystemSettings({ ...systemSettings, lowStockThreshold: e.target.value })}
              />
            </div>
            <div className="flex justify-end">
              <Button onClick={handleSaveSystemSettings}>
                <Save size={20} />
                حفظ التغييرات
              </Button>
            </div>
          </motion.div>
        )}

        {/* الإشعارات */}
        {activeTab === 'notifications' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="p-6 space-y-6"
          >
            <div className="space-y-4">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={notificationSettings.emailNotifications}
                  onChange={(e) => setNotificationSettings({ ...notificationSettings, emailNotifications: e.target.checked })}
                  className="w-5 h-5 text-primary rounded focus:ring-2 focus:ring-primary"
                />
                <span className="text-gray-700">تفعيل الإشعارات عبر البريد الإلكتروني</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={notificationSettings.lowStockAlerts}
                  onChange={(e) => setNotificationSettings({ ...notificationSettings, lowStockAlerts: e.target.checked })}
                  className="w-5 h-5 text-primary rounded focus:ring-2 focus:ring-primary"
                />
                <span className="text-gray-700">تنبيهات المخزون المنخفض</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={notificationSettings.paymentReminders}
                  onChange={(e) => setNotificationSettings({ ...notificationSettings, paymentReminders: e.target.checked })}
                  className="w-5 h-5 text-primary rounded focus:ring-2 focus:ring-primary"
                />
                <span className="text-gray-700">تذكيرات الدفع</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={notificationSettings.invoiceAlerts}
                  onChange={(e) => setNotificationSettings({ ...notificationSettings, invoiceAlerts: e.target.checked })}
                  className="w-5 h-5 text-primary rounded focus:ring-2 focus:ring-primary"
                />
                <span className="text-gray-700">تنبيهات الفواتير</span>
              </label>
            </div>
            <div className="flex justify-end">
              <Button onClick={handleSaveNotifications}>
                <Save size={20} />
                حفظ التغييرات
              </Button>
            </div>
          </motion.div>
        )}

        {/* المظهر */}
        {activeTab === 'appearance' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="p-6 space-y-6"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Select
                label="المظهر"
                value={appearanceSettings.theme}
                onChange={(e) => setAppearanceSettings({ ...appearanceSettings, theme: e.target.value })}
                options={[
                  { value: 'light', label: 'فاتح' },
                  { value: 'dark', label: 'داكن' },
                  { value: 'auto', label: 'تلقائي' }
                ]}
              />
              <Select
                label="اللغة"
                value={appearanceSettings.language}
                onChange={(e) => setAppearanceSettings({ ...appearanceSettings, language: e.target.value })}
                options={[
                  { value: 'ar', label: 'العربية' },
                  { value: 'en', label: 'English' }
                ]}
              />
              <Select
                label="تنسيق التاريخ"
                value={appearanceSettings.dateFormat}
                onChange={(e) => setAppearanceSettings({ ...appearanceSettings, dateFormat: e.target.value })}
                options={[
                  { value: 'DD/MM/YYYY', label: 'DD/MM/YYYY' },
                  { value: 'MM/DD/YYYY', label: 'MM/DD/YYYY' },
                  { value: 'YYYY-MM-DD', label: 'YYYY-MM-DD' }
                ]}
              />
              <Select
                label="تنسيق الأرقام"
                value={appearanceSettings.numberFormat}
                onChange={(e) => setAppearanceSettings({ ...appearanceSettings, numberFormat: e.target.value })}
                options={[
                  { value: 'en', label: '1,234.56' },
                  { value: 'ar', label: '١٬٢٣٤٫٥٦' }
                ]}
              />
            </div>
            <div className="flex justify-end">
              <Button onClick={handleSaveAppearance}>
                <Save size={20} />
                حفظ التغييرات
              </Button>
            </div>
          </motion.div>
        )}

        {/* إدارة البيانات */}
        {activeTab === 'data' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="p-6 space-y-6"
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button onClick={() => setShowBackupModal(true)} variant="outline">
                <Download size={20} />
                تصدير نسخة احتياطية
              </Button>
              <Button onClick={() => document.getElementById('import-file').click()} variant="outline">
                <Upload size={20} />
                استيراد نسخة احتياطية
              </Button>
              <input
                id="import-file"
                type="file"
                accept=".json"
                onChange={handleImportData}
                className="hidden"
              />
              <Button onClick={() => setShowClearModal(true)} variant="outline" className="text-red-600 border-red-600 hover:bg-red-50">
                <Trash2 size={20} />
                مسح جميع البيانات
              </Button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  )
}

export default Settings