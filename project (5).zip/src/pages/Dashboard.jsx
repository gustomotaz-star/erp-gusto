import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Package, Users, FileText, TrendingUp, AlertTriangle } from 'lucide-react'
import { motion } from 'framer-motion'
import { storage, getLowStockProducts } from '../utils/storage'
import { formatCurrency } from '../utils/calculations'
import Button from '../components/Button'

const Dashboard = () => {
  const [stats, setStats] = useState({
    totalProducts: 0,
    totalCustomers: 0,
    totalInvoices: 0,
    totalSales: 0,
    lowStockCount: 0
  })
  const [lowStockProducts, setLowStockProducts] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadDashboardData()
  }, [])

  const loadDashboardData = () => {
    try {
      setLoading(true)
      const products = storage.get('PRODUCTS') || []
      const customers = storage.get('CUSTOMERS') || []
      const invoices = storage.get('INVOICES') || []
      const lowStock = getLowStockProducts() || []

      const totalSales = invoices.reduce((sum, inv) => sum + (inv.final_total || 0), 0)

      setStats({
        totalProducts: products.length,
        totalCustomers: customers.length,
        totalInvoices: invoices.length,
        totalSales,
        lowStockCount: lowStock.length
      })
      setLowStockProducts(lowStock)
    } catch (error) {
      console.error('Error loading dashboard data:', error)
      setStats({
        totalProducts: 0,
        totalCustomers: 0,
        totalInvoices: 0,
        totalSales: 0,
        lowStockCount: 0
      })
      setLowStockProducts([])
    } finally {
      setLoading(false)
    }
  }

  const statCards = [
    { icon: Package, label: 'المنتجات', value: stats.totalProducts, color: 'bg-primary', link: '/products' },
    { icon: Users, label: 'العملاء', value: stats.totalCustomers, color: 'bg-success', link: '/customers' },
    { icon: FileText, label: 'الفواتير', value: stats.totalInvoices, color: 'bg-warning', link: '/invoices' },
    { icon: TrendingUp, label: 'إجمالي المبيعات', value: formatCurrency(stats.totalSales), color: 'bg-danger', link: '/reports' }
  ]

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-dark">لوحة التحكم</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {statCards.map((card, index) => {
          const Icon = card.icon
          return (
            <Link key={index} to={card.link}>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -5 }}
                className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-all"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm mb-1">{card.label}</p>
                    <p className="text-2xl font-bold text-dark">{card.value}</p>
                  </div>
                  <div className={`${card.color} p-4 rounded-lg text-white`}>
                    <Icon size={24} />
                  </div>
                </div>
              </motion.div>
            </Link>
          )
        })}
      </div>

      {stats.lowStockCount > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-lg p-6 shadow-md"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-warning p-3 rounded-lg text-white">
              <AlertTriangle size={24} />
            </div>
            <div>
              <h2 className="text-xl font-bold text-dark">تنبيه: منتجات قاربت على النفاد</h2>
              <p className="text-gray-600">يوجد {stats.lowStockCount} منتج أقل من الحد الأدنى</p>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-right py-3 px-4">كود المنتج</th>
                  <th className="text-right py-3 px-4">اسم المنتج</th>
                  <th className="text-right py-3 px-4">الكمية الحالية</th>
                  <th className="text-right py-3 px-4">الحد الأدنى</th>
                  <th className="text-right py-3 px-4">الإجراء</th>
                </tr>
              </thead>
              <tbody>
                {Array.isArray(lowStockProducts) && lowStockProducts.length > 0 ? (
                  lowStockProducts.map((product) => (
                  <tr key={product.id} className="border-b hover:bg-gray-50">
                    <td className="py-3 px-4">{product.product_code}</td>
                    <td className="py-3 px-4">{product.product_name}</td>
                    <td className="py-3 px-4">
                      <span className="text-danger font-semibold">{product.stock_quantity}</span>
                    </td>
                    <td className="py-3 px-4">{product.min_stock_level}</td>
                    <td className="py-3 px-4">
                      <Link to={`/products/edit/${product.id}`}>
                        <Button size="sm" variant="outline">تحديث المخزون</Button>
                      </Link>
                    </td>
                  </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="5" className="py-8 text-center text-gray-500">
                      {loading ? 'جاري التحميل...' : 'لا توجد منتجات قاربت على النفاد'}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </motion.div>
      )}
    </div>
  )
}

export default Dashboard