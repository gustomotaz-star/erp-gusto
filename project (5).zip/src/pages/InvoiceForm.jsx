import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { ArrowRight, Plus, Trash2 } from 'lucide-react'
import { storage, generateInvoiceNumber, updateInventory } from '../utils/storage'
import { calculateLineTotal, calculateInvoiceTotals } from '../utils/calculations'
import { paymentTypeOptions, taxOptions } from '../data/mockData'
import Button from '../components/Button'
import Input from '../components/Input'
import Select from '../components/Select'

const InvoiceForm = () => {
  const navigate = useNavigate()
  const { id } = useParams()
  const isEdit = Boolean(id)

  const [customers, setCustomers] = useState([])
  const [products, setProducts] = useState([])
  const [formData, setFormData] = useState({
    customer_id: '',
    invoice_date: new Date().toISOString().split('T')[0],
    invoice_number: '',
    payment_type: 'cash',
    due_date: '',
    invoice_discount: 0,
    notes: ''
  })
  const [items, setItems] = useState([{
    product_id: '',
    description: '',
    unit_price: 0,
    quantity: 1,
    discount_percent: 0,
    tax1: 0,
    tax2: 0
  }])

  useEffect(() => {
    loadData()
    if (!isEdit) {
      setFormData(prev => ({ ...prev, invoice_number: generateInvoiceNumber() }))
    }
  }, [])

  useEffect(() => {
    if (isEdit && id) {
      const invoice = storage.getById('INVOICES', id)
      if (invoice) {
        setFormData(invoice)
        const invoiceItems = storage.get('INVOICE_ITEMS').filter(item => item.invoice_id === id)
        if (invoiceItems.length > 0) {
          setItems(invoiceItems)
        }
      }
    }
  }, [id, isEdit])

  const loadData = () => {
    setCustomers(storage.get('CUSTOMERS').filter(c => c.status === 'active'))
    setProducts(storage.get('PRODUCTS').filter(p => p.status === 'active'))
  }

  const handleFormChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleItemChange = (index, field, value) => {
    const newItems = [...items]
    newItems[index][field] = value

    if (field === 'product_id') {
      const product = products.find(p => p.id === value)
      if (product) {
        newItems[index].description = product.product_name
        newItems[index].unit_price = product.sale_price
        newItems[index].tax1 = product.tax1
        newItems[index].tax2 = product.tax2
      }
    }

    setItems(newItems)
  }

  const addItem = () => {
    setItems([...items, {
      product_id: '',
      description: '',
      unit_price: 0,
      quantity: 1,
      discount_percent: 0,
      tax1: 0,
      tax2: 0
    }])
  }

  const removeItem = (index) => {
    if (items.length > 1) {
      setItems(items.filter((_, i) => i !== index))
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()

    const totals = calculateInvoiceTotals(items, parseFloat(formData.invoice_discount) || 0)
    const paidAmount = formData.payment_type === 'cash' ? totals.finalTotal : 0

    const invoiceData = {
      ...formData,
      invoice_discount: parseFloat(formData.invoice_discount) || 0,
      total_before_discount: totals.totalBeforeDiscount,
      tax_total: totals.taxTotal,
      final_total: totals.finalTotal,
      paid_amount: paidAmount,
      remaining_amount: totals.finalTotal - paidAmount
    }

    let savedInvoice
    if (isEdit) {
      savedInvoice = storage.update('INVOICES', id, invoiceData)
      const existingItems = storage.get('INVOICE_ITEMS').filter(item => item.invoice_id !== id)
      storage.set('INVOICE_ITEMS', existingItems)
    } else {
      savedInvoice = storage.add('INVOICES', invoiceData)
    }

    items.forEach(item => {
      const itemData = {
        invoice_id: savedInvoice.id,
        product_id: item.product_id,
        description: item.description,
        quantity: parseFloat(item.quantity) || 0,
        unit_price: parseFloat(item.unit_price) || 0,
        discount_percent: parseFloat(item.discount_percent) || 0,
        tax1: parseFloat(item.tax1) || 0,
        tax2: parseFloat(item.tax2) || 0,
        line_total: calculateLineTotal(
          parseFloat(item.unit_price) || 0,
          parseFloat(item.quantity) || 0,
          parseFloat(item.discount_percent) || 0,
          parseFloat(item.tax1) || 0,
          parseFloat(item.tax2) || 0
        ).lineTotal
      }
      storage.add('INVOICE_ITEMS', itemData)

      if (!isEdit && item.product_id) {
        updateInventory(item.product_id, parseFloat(item.quantity) || 0)
      }
    })

    if (formData.payment_type === 'cash') {
      storage.add('PAYMENTS', {
        invoice_id: savedInvoice.id,
        amount: totals.finalTotal,
        payment_date: formData.invoice_date,
        payment_method: 'cash',
        notes: 'دفعة نقدية كاملة'
      })
    }

    navigate('/invoices')
  }

  const totals = calculateInvoiceTotals(items, parseFloat(formData.invoice_discount) || 0)

  return (
    <div>
      <div className="flex items-center gap-4 mb-6">
        <button onClick={() => navigate('/invoices')} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
          <ArrowRight size={24} />
        </button>
        <h1 className="text-3xl font-bold text-dark">
          {isEdit ? 'تعديل فاتورة' : 'إنشاء فاتورة جديدة'}
        </h1>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-xl font-bold mb-4">معلومات الفاتورة</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Select
              label="العميل"
              name="customer_id"
              value={formData.customer_id}
              onChange={handleFormChange}
              options={customers.map(c => ({ value: c.id, label: c.customer_name }))}
              required
            />
            <Input
              label="رقم الفاتورة"
              name="invoice_number"
              value={formData.invoice_number}
              onChange={handleFormChange}
              disabled
            />
            <Input
              label="تاريخ الفاتورة"
              name="invoice_date"
              type="date"
              value={formData.invoice_date}
              onChange={handleFormChange}
              required
            />
            <Select
              label="نوع الدفع"
              name="payment_type"
              value={formData.payment_type}
              onChange={handleFormChange}
              options={paymentTypeOptions}
              required
            />
            {formData.payment_type === 'credit' && (
              <Input
                label="تاريخ الاستحقاق"
                name="due_date"
                type="date"
                value={formData.due_date}
                onChange={handleFormChange}
                required
              />
            )}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold">بنود الفاتورة</h2>
            <Button type="button" onClick={addItem} size="sm">
              <Plus size={16} className="ml-1" />
              إضافة بند
            </Button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="text-right py-3 px-4 font-semibold">المنتج</th>
                  <th className="text-right py-3 px-4 font-semibold">الوصف</th>
                  <th className="text-right py-3 px-4 font-semibold">السعر</th>
                  <th className="text-right py-3 px-4 font-semibold">الكمية</th>
                  <th className="text-right py-3 px-4 font-semibold">الخصم %</th>
                  <th className="text-right py-3 px-4 font-semibold">ض1 %</th>
                  <th className="text-right py-3 px-4 font-semibold">ض2 %</th>
                  <th className="text-right py-3 px-4 font-semibold">الإجمالي</th>
                  <th className="text-right py-3 px-4 font-semibold"></th>
                </tr>
              </thead>
              <tbody>
                {items.map((item, index) => {
                  const lineCalc = calculateLineTotal(
                    parseFloat(item.unit_price) || 0,
                    parseFloat(item.quantity) || 0,
                    parseFloat(item.discount_percent) || 0,
                    parseFloat(item.tax1) || 0,
                    parseFloat(item.tax2) || 0
                  )
                  return (
                    <tr key={index} className="border-b">
                      <td className="py-3 px-4">
                        <select
                          value={item.product_id}
                          onChange={(e) => handleItemChange(index, 'product_id', e.target.value)}
                          className="w-full px-2 py-1 border rounded focus:outline-none focus:ring-2 focus:ring-primary"
                          required
                        >
                          <option value="">اختر منتج</option>
                          {products.map(p => (
                            <option key={p.id} value={p.id}>{p.product_name}</option>
                          ))}
                        </select>
                      </td>
                      <td className="py-3 px-4">
                        <input
                          type="text"
                          value={item.description}
                          onChange={(e) => handleItemChange(index, 'description', e.target.value)}
                          className="w-full px-2 py-1 border rounded focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                      </td>
                      <td className="py-3 px-4">
                        <input
                          type="number"
                          step="0.01"
                          value={item.unit_price}
                          onChange={(e) => handleItemChange(index, 'unit_price', e.target.value)}
                          className="w-20 px-2 py-1 border rounded focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                      </td>
                      <td className="py-3 px-4">
                        <input
                          type="number"
                          value={item.quantity}
                          onChange={(e) => handleItemChange(index, 'quantity', e.target.value)}
                          className="w-16 px-2 py-1 border rounded focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                      </td>
                      <td className="py-3 px-4">
                        <input
                          type="number"
                          step="0.01"
                          value={item.discount_percent}
                          onChange={(e) => handleItemChange(index, 'discount_percent', e.target.value)}
                          className="w-16 px-2 py-1 border rounded focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                      </td>
                      <td className="py-3 px-4">
                        <select
                          value={item.tax1}
                          onChange={(e) => handleItemChange(index, 'tax1', e.target.value)}
                          className="w-20 px-2 py-1 border rounded focus:outline-none focus:ring-2 focus:ring-primary"
                        >
                          {taxOptions.map(t => (
                            <option key={t.value} value={t.value}>{t.label}</option>
                          ))}
                        </select>
                      </td>
                      <td className="py-3 px-4">
                        <select
                          value={item.tax2}
                          onChange={(e) => handleItemChange(index, 'tax2', e.target.value)}
                          className="w-20 px-2 py-1 border rounded focus:outline-none focus:ring-2 focus:ring-primary"
                        >
                          {taxOptions.map(t => (
                            <option key={t.value} value={t.value}>{t.label}</option>
                          ))}
                        </select>
                      </td>
                      <td className="py-3 px-4 font-semibold">
                        {lineCalc.lineTotal.toFixed(2)}
                      </td>
                      <td className="py-3 px-4">
                        {items.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeItem(index)}
                            className="p-1 text-danger hover:bg-danger/10 rounded transition-colors"
                          >
                            <Trash2 size={16} />
                          </button>
                        )}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="max-w-md mr-auto">
            <div className="flex justify-between py-2 border-b">
              <span>الإجمالي قبل الخصم:</span>
              <span className="font-semibold">{totals.totalBeforeDiscount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between py-2 border-b items-center">
              <span>خصم الفاتورة %:</span>
              <input
                type="number"
                step="0.01"
                name="invoice_discount"
                value={formData.invoice_discount}
                onChange={handleFormChange}
                className="w-24 px-2 py-1 border rounded focus:outline-none focus:ring-2 focus:ring-primary text-left"
              />
            </div>
            <div className="flex justify-between py-2 border-b">
              <span>مبلغ الخصم:</span>
              <span className="font-semibold text-danger">-{totals.invoiceDiscountAmount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between py-2 border-b">
              <span>إجمالي الضرائب:</span>
              <span className="font-semibold">{totals.taxTotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between py-3 text-xl font-bold">
              <span>الإجمالي النهائي:</span>
              <span className="text-primary">{totals.finalTotal.toFixed(2)}</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <Input
            label="ملاحظات"
            name="notes"
            value={formData.notes}
            onChange={handleFormChange}
          />
        </div>

        <div className="flex gap-4">
          <Button type="submit">
            {isEdit ? 'حفظ التعديلات' : 'حفظ الفاتورة'}
          </Button>
          <Button type="button" variant="outline" onClick={() => navigate('/invoices')}>
            إلغاء
          </Button>
        </div>
      </form>
    </div>
  )
}

export default InvoiceForm