import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Plus, Eye, Edit, Trash2, Search } from 'lucide-react'
import { motion } from 'framer-motion'
import { storage } from '../utils/storage'
import { formatCurrency } from '../utils/calculations'
import Button from '../components/Button'

const Invoices = () => {
  const [invoices, setInvoices] = useState([])
  const [customers, setCustomers] = useState([])
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [paymentTypeFilter, setPaymentTypeFilter] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = () => {
    try {
      setLoading(true)
      const invoicesData = storage.get('INVOICES') || []
      const customersData = storage.get('CUSTOMERS') || []
      setInvoices(Array.isArray(invoicesData) ? invoicesData : [])
      setCustomers(Array.isArray(customersData) ? customersData : [])
    } catch (error) {
      console.error('Error loading data:', error)
      setInvoices([])
      setCustomers([])
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = (id) => {
    if (window.confirm('هل أنت متأكد من حذف هذه الفاتورة؟')) {
      storage.delete('INVOICES', id)
      const items = storage.get('INVOICE_ITEMS').filter(item => item.invoice_id !== id)
      storage.set('INVOICE_ITEMS', items)
      loadData()
    }
  }

  const getCustomerName = (customerId) => {
    if (!Array.isArray(customers)) return '-'
    const customer = customers.find(c => c.id === customerId)
    return customer?.customer_name || '-'
  }

  const getStatusLabel = (invoice) => {
    const remaining = invoice.final_total - (invoice.paid_amount || 0)
    if (remaining <= 0) return { label: 'مدفوع', color: 'bg-success/20 text-success' }
    if (invoice.paid_amount > 0) return { label: 'مدفوع جزئياً', color: 'bg-warning/20 text-warning' }
    return { label: 'غير مدفوع', color: 'bg-danger/20 text-danger' }
  }

  const filteredInvoices = []
  if (Array.isArray(invoices)) {
    for (let i = 0; i < invoices.length; i++) {
      const invoice = invoices[i]
      const customerName = getCustomerName(invoice.customer_id)
      const matchesSearch = invoice.invoice_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           customerName.toLowerCase().includes(searchTerm.toLowerCase())
      const status = getStatusLabel(invoice)
      const matchesStatus = !statusFilter ||
        (statusFilter === 'paid' && status.label === 'مدفوع') ||
        (statusFilter === 'partial' && status.label === 'مدفوع جزئياً') ||
        (statusFilter === 'unpaid' && status.label === 'غير مدفوع')
      const matchesPaymentType = !paymentTypeFilter || invoice.payment_type === paymentTypeFilter
      if (matchesSearch && matchesStatus && matchesPaymentType) {
        filteredInvoices.push(invoice)
      }
    }
  }

  const renderInvoiceRows = () => {
    const rows = []
    for (let i = 0; i < filteredInvoices.length; i++) {
      const invoice = filteredInvoices[i]
      const status = getStatusLabel(invoice)
      const remaining = invoice.final_total - (invoice.paid_amount || 0)
      rows.push(
        <motion.tr
          key={invoice.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.05 }}
          className="border-b hover:bg-gray-50"
        >
          <td className="py-4 px-6 font-semibold">{invoice.invoice_number}</td>
          <td className="py-4 px-6">{getCustomerName(invoice.customer_id)}</td>
          <td className="py-4 px-6">{invoice.invoice_date}</td>
          <td className="py-4 px-6">{formatCurrency(invoice.final_total)}</td>
          <td className="py-4 px-6">{formatCurrency(invoice.paid_amount || 0)}</td>
          <td className="py-4 px-6">
            <span className={remaining > 0 ? 'text-danger font-semibold' : ''}>
              {formatCurrency(remaining)}
            </span>
          </td>
          <td className="py-4 px-6">
            <span className={`px-3 py-1 rounded-full text-sm ${status.color}`}>
              {status.label}
            </span>
          </td>
          <td className="py-4 px-6">
            <div className="flex gap-2">
              <Link to={`/invoices/view/${invoice.id}`}>
                <button className="p-2 text-primary hover:bg-primary/10 rounded-lg transition-colors">
                  <Eye size={18} />
                </button>
              </Link>
              <Link to={`/invoices/edit/${invoice.id}`}>
                <button className="p-2 text-success hover:bg-success/10 rounded-lg transition-colors">
                  <Edit size={18} />
                </button>
              </Link>
              <button
                onClick={() => handleDelete(invoice.id)}
                className="p-2 text-danger hover:bg-danger/10 rounded-lg transition-colors"
              >
                <Trash2 size={18} />
              </button>
            </div>
          </td>
        </motion.tr>
      )
    }
    return rows
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-dark">الفواتير</h1>
        <Link to="/invoices/new">
          <Button>
            <Plus size={20} className="ml-2" />
            إنشاء فاتورة جديدة
          </Button>
        </Link>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="بحث برقم الفاتورة أو العميل..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pr-10 pl-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="">جميع الحالات</option>
            <option value="paid">مدفوع</option>
            <option value="partial">مدفوع جزئياً</option>
            <option value="unpaid">غير مدفوع</option>
          </select>
          <select
            value={paymentTypeFilter}
            onChange={(e) => setPaymentTypeFilter(e.target.value)}
            className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="">جميع أنواع الدفع</option>
            <option value="cash">نقدي</option>
            <option value="credit">آجل</option>
          </select>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="text-right py-4 px-6 font-semibold">رقم الفاتورة</th>
                <th className="text-right py-4 px-6 font-semibold">العميل</th>
                <th className="text-right py-4 px-6 font-semibold">التاريخ</th>
                <th className="text-right py-4 px-6 font-semibold">الإجمالي</th>
                <th className="text-right py-4 px-6 font-semibold">المدفوع</th>
                <th className="text-right py-4 px-6 font-semibold">المتبقي</th>
                <th className="text-right py-4 px-6 font-semibold">الحالة</th>
                <th className="text-right py-4 px-6 font-semibold">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="8" className="py-12 text-center text-gray-500">
                    جاري التحميل...
                  </td>
                </tr>
              ) : filteredInvoices.length > 0 ? (
                renderInvoiceRows()
              ) : (
                <tr>
                  <td colSpan="8" className="py-12 text-center text-gray-500">
                    لا توجد فواتير
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

export default Invoices