import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'
import { storage } from '../utils/storage'
import { statusOptions } from '../data/mockData'
import Button from '../components/Button'
import Input from '../components/Input'
import Select from '../components/Select'

const CustomerForm = () => {
  const navigate = useNavigate()
  const { id } = useParams()
  const isEdit = Boolean(id)

  // ==== تحميل جميع العملاء لاستخراج أعلى رقم كود ====
  const allCustomers = storage.get('CUSTOMERS') || []

  // ==== دالة توليد كود عميل تلقائي ====
  const generateCustomerCode = () => {
    if (!Array.isArray(allCustomers) || allCustomers.length === 0) {
      return "CUST-0001"
    }

    const numbers = allCustomers
      .map(c => parseInt(c.customer_code?.replace("CUST-", "")))
      .filter(n => !isNaN(n))

    const next = Math.max(...numbers, 0) + 1
    return `CUST-${String(next).padStart(4, "0")}`
  }

  const [formData, setFormData] = useState({
    customer_code: generateCustomerCode(), // ← يظهر داخل الفورم
    customer_name: '',
    phone: '',
    email: '',
    address: '',
    tax_number: '',
    status: 'active'
  })

  // ==== تحميل البيانات عند التعديل ====
  useEffect(() => {
    if (isEdit) {
      const customer = storage.getById('CUSTOMERS', id)
      if (customer) {
        setFormData(customer)
      }
    }
  }, [id, isEdit])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()

    if (isEdit) {
      storage.update('CUSTOMERS', id, formData)
    } else {
      storage.add('CUSTOMERS', formData)
    }

    navigate('/customers')
  }

  return (
    <div>
      <div className="flex items-center gap-4 mb-6">
        <button
          onClick={() => navigate('/customers')}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowRight size={24} />
        </button>
        <h1 className="text-3xl font-bold text-dark">
          {isEdit ? 'تعديل عميل' : 'إضافة عميل جديد'}
        </h1>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

            {/* ==== كود العميل (قراءة فقط) ==== */}
            <Input
              label="كود العميل"
              name="customer_code"
              value={formData.customer_code}
              readOnly
            />

            <Input
              label="اسم العميل"
              name="customer_name"
              value={formData.customer_name}
              onChange={handleChange}
              required
            />
            <Input
              label="رقم الهاتف"
              name="phone"
              type="tel"
              value={formData.phone}
              onChange={handleChange}
              required
            />
            <Input
              label="البريد الإلكتروني"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
            />
            <Input
              label="الرقم الضريبي"
              name="tax_number"
              value={formData.tax_number}
              onChange={handleChange}
            />
            <div className="md:col-span-2">
              <Input
                label="العنوان"
                name="address"
                value={formData.address}
                onChange={handleChange}
              />
            </div>

            <Select
              label="الحالة"
              name="status"
              value={formData.status}
              onChange={handleChange}
              options={statusOptions}
              required
            />
          </div>

          <div className="flex gap-4 mt-6">
            <Button type="submit">
              {isEdit ? 'حفظ التعديلات' : 'إضافة العميل'}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate('/customers')}
            >
              إلغاء
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default CustomerForm
