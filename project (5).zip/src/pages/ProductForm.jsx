import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'
import { storage } from '../utils/storage'
import { taxOptions, statusOptions } from '../data/mockData'
import Button from '../components/Button'
import Input from '../components/Input'
import Select from '../components/Select'

const ProductForm = () => {
  const navigate = useNavigate()
  const { id } = useParams()
  const isEdit = Boolean(id)

  const [formData, setFormData] = useState({
    product_code: '',
    product_name: '',
    description: '',
    cost_price: '',
    sale_price: '',
    stock_quantity: '',
    min_stock_level: '',
    tax1: '0',
    tax2: '0',
    status: 'active'
  })

  useEffect(() => {
    if (isEdit) {
      const product = storage.getById('PRODUCTS', id)
      if (product) {
        setFormData(product)
      }
    }
  }, [id, isEdit])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    
    const productData = {
      ...formData,
      cost_price: parseFloat(formData.cost_price) || 0,
      sale_price: parseFloat(formData.sale_price) || 0,
      stock_quantity: parseInt(formData.stock_quantity) || 0,
      min_stock_level: parseInt(formData.min_stock_level) || 0,
      tax1: parseFloat(formData.tax1) || 0,
      tax2: parseFloat(formData.tax2) || 0
    }

    if (isEdit) {
      storage.update('PRODUCTS', id, productData)
    } else {
      storage.add('PRODUCTS', productData)
    }

    navigate('/products')
  }

  return (
    <div>
      <div className="flex items-center gap-4 mb-6">
        <button
          onClick={() => navigate('/products')}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowRight size={24} />
        </button>
        <h1 className="text-3xl font-bold text-dark">
          {isEdit ? 'تعديل منتج' : 'إضافة منتج جديد'}
        </h1>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input
              label="كود المنتج"
              name="product_code"
              value={formData.product_code}
              onChange={handleChange}
              required
            />
            <Input
              label="اسم المنتج"
              name="product_name"
              value={formData.product_name}
              onChange={handleChange}
              required
            />
            <div className="md:col-span-2">
              <Input
                label="الوصف"
                name="description"
                value={formData.description}
                onChange={handleChange}
              />
            </div>
            <Input
              label="سعر التكلفة"
              name="cost_price"
              type="number"
              step="0.01"
              value={formData.cost_price}
              onChange={handleChange}
              required
            />
            <Input
              label="سعر البيع"
              name="sale_price"
              type="number"
              step="0.01"
              value={formData.sale_price}
              onChange={handleChange}
              required
            />
            <Input
              label="الكمية في المخزون"
              name="stock_quantity"
              type="number"
              value={formData.stock_quantity}
              onChange={handleChange}
              required
            />
            <Input
              label="الحد الأدنى للمخزون"
              name="min_stock_level"
              type="number"
              value={formData.min_stock_level}
              onChange={handleChange}
              required
            />
            <Select
              label="الضريبة الأولى"
              name="tax1"
              value={formData.tax1}
              onChange={handleChange}
              options={taxOptions}
            />
            <Select
              label="الضريبة الثانية"
              name="tax2"
              value={formData.tax2}
              onChange={handleChange}
              options={taxOptions}
            />
            <Select
              label="الحالة"
              name="status"
              value={formData.status}
              onChange={handleChange}
              options={statusOptions}
              required
            />
          </div>

          <div className="flex gap-4 mt-6">
            <Button type="submit">
              {isEdit ? 'حفظ التعديلات' : 'إضافة المنتج'}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate('/products')}
            >
              إلغاء
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default ProductForm