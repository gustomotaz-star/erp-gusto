import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Plus, Edit, Trash2, Search } from 'lucide-react'
import { motion } from 'framer-motion'
import { storage } from '../utils/storage'
import { formatCurrency } from '../utils/calculations'
import Button from '../components/Button'

const Products = () => {
  const [products, setProducts] = useState([])
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadProducts()
  }, [])

  const loadProducts = () => {
    try {
      setLoading(true)
      const data = storage.get('PRODUCTS') || []
      setProducts(Array.isArray(data) ? data : [])
    } catch (error) {
      console.error('Error loading products:', error)
      setProducts([])
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = (id) => {
    if (window.confirm('هل أنت متأكد من حذف هذا المنتج؟')) {
      storage.delete('PRODUCTS', id)
      loadProducts()
    }
  }

  const filteredProducts = []
  if (Array.isArray(products)) {
    for (let i = 0; i < products.length; i++) {
      const product = products[i]
      const matchesSearch = product.product_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           product.product_code?.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesStatus = !statusFilter || product.status === statusFilter
      if (matchesSearch && matchesStatus) {
        filteredProducts.push(product)
      }
    }
  }

  const renderProductRows = () => {
    const rows = []
    for (let i = 0; i < filteredProducts.length; i++) {
      const product = filteredProducts[i]
      rows.push(
        <motion.tr
          key={product.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.05 }}
          className="border-b hover:bg-gray-50"
        >
          <td className="py-4 px-6">{product.product_code}</td>
          <td className="py-4 px-6 font-semibold">{product.product_name}</td>
          <td className="py-4 px-6">{formatCurrency(product.cost_price)}</td>
          <td className="py-4 px-6">{formatCurrency(product.sale_price)}</td>
          <td className="py-4 px-6">
            <span className={`font-semibold ${
              product.stock_quantity <= product.min_stock_level
                ? 'text-danger'
                : 'text-success'
            }`}>
              {product.stock_quantity}
            </span>
          </td>
          <td className="py-4 px-6">
            <span className={`px-3 py-1 rounded-full text-sm ${
              product.status === 'active'
                ? 'bg-success/20 text-success'
                : 'bg-gray-200 text-gray-600'
            }`}>
              {product.status === 'active' ? 'نشط' : 'غير نشط'}
            </span>
          </td>
          <td className="py-4 px-6">
            <div className="flex gap-2">
              <Link to={`/products/edit/${product.id}`}>
                <button className="p-2 text-primary hover:bg-primary/10 rounded-lg transition-colors">
                  <Edit size={18} />
                </button>
              </Link>
              <button
                onClick={() => handleDelete(product.id)}
                className="p-2 text-danger hover:bg-danger/10 rounded-lg transition-colors"
              >
                <Trash2 size={18} />
              </button>
            </div>
          </td>
        </motion.tr>
      )
    }
    return rows
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-dark">المنتجات</h1>
        <Link to="/products/new">
          <Button>
            <Plus size={20} className="ml-2" />
            إضافة منتج جديد
          </Button>
        </Link>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="بحث بالاسم أو الكود..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pr-10 pl-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="">جميع الحالات</option>
            <option value="active">نشط</option>
            <option value="inactive">غير نشط</option>
          </select>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="text-right py-4 px-6 font-semibold">الكود</th>
                <th className="text-right py-4 px-6 font-semibold">اسم المنتج</th>
                <th className="text-right py-4 px-6 font-semibold">سعر التكلفة</th>
                <th className="text-right py-4 px-6 font-semibold">سعر البيع</th>
                <th className="text-right py-4 px-6 font-semibold">الكمية</th>
                <th className="text-right py-4 px-6 font-semibold">الحالة</th>
                <th className="text-right py-4 px-6 font-semibold">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="7" className="py-12 text-center text-gray-500">
                    جاري التحميل...
                  </td>
                </tr>
              ) : filteredProducts.length > 0 ? (
                renderProductRows()
              ) : (
                <tr>
                  <td colSpan="7" className="py-12 text-center text-gray-500">
                    لا توجد منتجات
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

export default Products