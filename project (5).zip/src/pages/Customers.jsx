import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Plus, Edit, Trash2, Search, Check } from 'lucide-react'
import { motion } from 'framer-motion'
import { storage } from '../utils/storage'
import Button from '../components/Button'

const Customers = () => {
  const [customers, setCustomers] = useState([])
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [loading, setLoading] = useState(true)
  const [selectedCustomers, setSelectedCustomers] = useState([])

  useEffect(() => {
    loadCustomers()
  }, [])

  const loadCustomers = () => {
    try {
      setLoading(true)
      const data = storage.get('CUSTOMERS') || []
      setCustomers(Array.isArray(data) ? data : [])
    } catch (error) {
      console.error('Error loading customers:', error)
      setCustomers([])
    } finally {
      setLoading(false)
    }
  }

  // -----------------------------------------
  // FILTER LOGIC
  // -----------------------------------------
  const filteredCustomers = []
  if (Array.isArray(customers)) {
    for (let i = 0; i < customers.length; i++) {
      const customer = customers[i]
      const matchesSearch =
        customer.customer_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.phone?.includes(searchTerm) ||
        customer.email?.toLowerCase().includes(searchTerm.toLowerCase())

      const matchesStatus = !statusFilter || customer.status === statusFilter

      if (matchesSearch && matchesStatus) {
        filteredCustomers.push(customer)
      }
    }
  }

  const isSelected = (customerId) => selectedCustomers.includes(customerId)
  const isAllSelected =
    filteredCustomers.length > 0 &&
    selectedCustomers.length === filteredCustomers.length

  // -----------------------------------------
  // DELETE SINGLE
  // -----------------------------------------
  const handleDelete = (id) => {
    if (window.confirm('هل أنت متأكد من حذف هذا العميل؟')) {
      storage.delete('CUSTOMERS', id)
      loadCustomers()
      setSelectedCustomers(selectedCustomers.filter((cid) => cid !== id))
    }
  }

  // -----------------------------------------
  // SELECT ALL
  // -----------------------------------------
  const handleSelectAll = () => {
    if (isAllSelected) {
      setSelectedCustomers([])
    } else {
      const allIds = filteredCustomers.map((c) => c.id)
      setSelectedCustomers(allIds)
    }
  }

  // -----------------------------------------
  // SELECT SINGLE
  // -----------------------------------------
  const handleSelectCustomer = (customerId) => {
    if (selectedCustomers.includes(customerId)) {
      setSelectedCustomers(selectedCustomers.filter((id) => id !== customerId))
    } else {
      setSelectedCustomers([...selectedCustomers, customerId])
    }
  }

  // -----------------------------------------
  // 🔥 NEW: BULK DELETE FUNCTION
  // -----------------------------------------
  const handleBulkDelete = () => {
    if (selectedCustomers.length === 0) return

    if (!window.confirm('هل تريد حذف جميع العملاء المحددين؟')) return

    const remaining = customers.filter(
      (cust) => !selectedCustomers.includes(cust.id)
    )

    storage.set('CUSTOMERS', remaining)
    loadCustomers()
    setSelectedCustomers([])
  }

  // -----------------------------------------
  // TABLE ROWS
  // -----------------------------------------
  const renderCustomerRows = () => {
    const rows = []
    for (let i = 0; i < filteredCustomers.length; i++) {
      const customer = filteredCustomers[i]
      const selected = isSelected(customer.id)

      rows.push(
        <motion.tr
          key={customer.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.05 }}
          className={`border-b hover:bg-gray-50 transition-colors ${
            selected ? 'bg-primary/5' : ''
          }`}
        >
          <td className="py-4 px-6">
            <div className="flex items-center justify-center">
              <button
                onClick={() => handleSelectCustomer(customer.id)}
                className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${
                  selected
                    ? 'bg-primary border-primary text-white'
                    : 'border-gray-300 hover:border-primary'
                }`}
              >
                {selected && <Check size={14} strokeWidth={3} />}
              </button>
            </div>
          </td>

          <td className="py-4 px-6 font-semibold">{customer.customer_name}</td>
          <td className="py-4 px-6" dir="ltr" style={{ textAlign: 'right' }}>{customer.phone}</td>
          <td className="py-4 px-6">{customer.email}</td>
          <td className="py-4 px-6">{customer.tax_number || '-'}</td>

          <td className="py-4 px-6">
            <span className={`px-3 py-1 rounded-full text-sm ${
              customer.status === 'active'
                ? 'bg-success/20 text-success'
                : 'bg-gray-200 text-gray-600'
            }`}>
              {customer.status === 'active' ? 'نشط' : 'غير نشط'}
            </span>
          </td>

          <td className="py-4 px-6">
            <div className="flex gap-2">
              <Link to={`/customers/edit/${customer.id}`}>
                <button className="p-2 text-primary hover:bg-primary/10 rounded-lg transition-colors">
                  <Edit size={18} />
                </button>
              </Link>
              <button
                onClick={() => handleDelete(customer.id)}
                className="p-2 text-danger hover:bg-danger/10 rounded-lg transition-colors"
              >
                <Trash2 size={18} />
              </button>
            </div>
          </td>
        </motion.tr>
      )
    }
    return rows
  }

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-dark">العملاء</h1>
        <Link to="/customers/new">
          <Button>
            <Plus size={20} className="ml-2" />
            إضافة عميل جديد
          </Button>
        </Link>
      </div>

      {/* SEARCH / FILTER */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="بحث بالاسم، الهاتف أو البريد..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pr-10 pl-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="">جميع الحالات</option>
            <option value="active">نشط</option>
            <option value="inactive">غير نشط</option>
          </select>
        </div>
      </div>

      {/* NEW: زر الحذف الجماعي */}
      {selectedCustomers.length > 0 && (
        <div className="mb-4">
          <Button onClick={handleBulkDelete} className="bg-danger text-white hover:bg-danger/80">
            حذف المحدد ({selectedCustomers.length})
          </Button>
        </div>
      )}

      {/* TABLE */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="py-4 px-6 w-12 text-center">
                  <button
                    onClick={handleSelectAll}
                    className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${
                      isAllSelected
                        ? 'bg-primary border-primary text-white'
                        : 'border-gray-300 hover:border-primary'
                    }`}
                  >
                    {isAllSelected && <Check size={14} strokeWidth={3} />}
                  </button>
                </th>

                <th className="text-right py-4 px-6 font-semibold">اسم العميل</th>
                <th className="text-right py-4 px-6 font-semibold">الهاتف</th>
                <th className="text-right py-4 px-6 font-semibold">البريد الإلكتروني</th>
                <th className="text-right py-4 px-6 font-semibold">الرقم الضريبي</th>
                <th className="text-right py-4 px-6 font-semibold">الحالة</th>
                <th className="text-right py-4 px-6 font-semibold">الإجراءات</th>
              </tr>
            </thead>

            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="7" className="py-12 text-center text-gray-500">
                    جاري التحميل...
                  </td>
                </tr>
              ) : filteredCustomers.length > 0 ? (
                renderCustomerRows()
              ) : (
                <tr>
                  <td colSpan="7" className="py-12 text-center text-gray-500">
                    لا توجد عملاء
                  </td>
                </tr>
              )}
            </tbody>

          </table>
        </div>
      </div>
    </div>
  )
}

export default Customers