import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'
import { storage } from '../utils/storage'
import { formatCurrency } from '../utils/calculations'
import { paymentMethodOptions } from '../data/mockData'
import Button from '../components/Button'
import Input from '../components/Input'
import Select from '../components/Select'

const PaymentForm = () => {
  const navigate = useNavigate()
  const { invoiceId } = useParams()
  const [invoice, setInvoice] = useState(null)
  const [formData, setFormData] = useState({
    amount: '',
    payment_date: new Date().toISOString().split('T')[0],
    payment_method: 'cash',
    notes: ''
  })

  useEffect(() => {
    if (invoiceId) {
      const invoiceData = storage.getById('INVOICES', invoiceId)
      if (invoiceData) {
        setInvoice(invoiceData)
        const remaining = invoiceData.final_total - (invoiceData.paid_amount || 0)
        setFormData(prev => ({ ...prev, amount: remaining.toFixed(2) }))
      }
    }
  }, [invoiceId])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()

    const paymentAmount = parseFloat(formData.amount) || 0
    const remaining = invoice.final_total - (invoice.paid_amount || 0)

    if (paymentAmount > remaining) {
      alert('المبلغ المدخل أكبر من المبلغ المتبقي')
      return
    }

    const paymentData = {
      invoice_id: invoiceId,
      amount: paymentAmount,
      payment_date: formData.payment_date,
      payment_method: formData.payment_method,
      notes: formData.notes
    }

    storage.add('PAYMENTS', paymentData)

    const newPaidAmount = (invoice.paid_amount || 0) + paymentAmount
    const newRemaining = invoice.final_total - newPaidAmount

    storage.update('INVOICES', invoiceId, {
      paid_amount: newPaidAmount,
      remaining_amount: newRemaining
    })

    navigate(`/invoices/view/${invoiceId}`)
  }

  if (!invoice) {
    return <div className="text-center py-12">جاري التحميل...</div>
  }

  const remaining = invoice.final_total - (invoice.paid_amount || 0)

  return (
    <div>
      <div className="flex items-center gap-4 mb-6">
        <button
          onClick={() => navigate(`/invoices/view/${invoiceId}`)}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowRight size={24} />
        </button>
        <h1 className="text-3xl font-bold text-dark">إضافة دفعة</h1>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-bold mb-4">معلومات الفاتورة</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <p className="text-sm text-gray-600">رقم الفاتورة</p>
            <p className="font-semibold">{invoice.invoice_number}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">الإجمالي</p>
            <p className="font-semibold">{formatCurrency(invoice.final_total)}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">المدفوع</p>
            <p className="font-semibold text-success">{formatCurrency(invoice.paid_amount || 0)}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">المتبقي</p>
            <p className="font-semibold text-danger">{formatCurrency(remaining)}</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input
              label="المبلغ"
              name="amount"
              type="number"
              step="0.01"
              value={formData.amount}
              onChange={handleChange}
              required
            />
            <Input
              label="تاريخ الدفع"
              name="payment_date"
              type="date"
              value={formData.payment_date}
              onChange={handleChange}
              required
            />
            <Select
              label="طريقة الدفع"
              name="payment_method"
              value={formData.payment_method}
              onChange={handleChange}
              options={paymentMethodOptions}
              required
            />
            <div className="md:col-span-2">
              <Input
                label="ملاحظات"
                name="notes"
                value={formData.notes}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="flex gap-4 mt-6">
            <Button type="submit">حفظ الدفعة</Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate(`/invoices/view/${invoiceId}`)}
            >
              إلغاء
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default PaymentForm