import { useState, useEffect } from 'react'
import { TrendingUp, Package, Users, DollarSign } from 'lucide-react'
import { motion } from 'framer-motion'
import { storage } from '../utils/storage'
import { formatCurrency, calculateProfit } from '../utils/calculations'
import { format, startOfMonth, endOfMonth, isWithinInterval } from 'date-fns'
import { ar } from 'date-fns/locale'

const Reports = () => {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0])
  const [selectedMonth, setSelectedMonth] = useState(format(new Date(), 'yyyy-MM'))
  const [dailyReport, setDailyReport] = useState(null)
  const [monthlyReport, setMonthlyReport] = useState(null)
  const [productReport, setProductReport] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    generateDailyReport()
  }, [selectedDate])

  useEffect(() => {
    generateMonthlyReport()
  }, [selectedMonth])

  useEffect(() => {
    generateProductReport()
  }, [])

  const generateDailyReport = () => {
    try {
      setLoading(true)
      const allInvoices = storage.get('INVOICES') || []
      const invoices = []
      if (Array.isArray(allInvoices)) {
        for (let i = 0; i < allInvoices.length; i++) {
          if (allInvoices[i].invoice_date === selectedDate) {
            invoices.push(allInvoices[i])
          }
        }
      }

      let totalSales = 0
      let cashSales = 0
      let creditSales = 0

      for (let i = 0; i < invoices.length; i++) {
        const inv = invoices[i]
        totalSales += (inv.final_total || 0)
        if (inv.payment_type === 'cash') {
          cashSales += (inv.final_total || 0)
        } else if (inv.payment_type === 'credit') {
          creditSales += (inv.final_total || 0)
        }
      }

      setDailyReport({
        date: selectedDate,
        invoiceCount: invoices.length,
        totalSales,
        cashSales,
        creditSales,
        invoices
      })
    } catch (error) {
      console.error('Error generating daily report:', error)
      setDailyReport(null)
    } finally {
      setLoading(false)
    }
  }

  const generateMonthlyReport = () => {
    try {
      setLoading(true)
      const [year, month] = selectedMonth.split('-')
      const startDate = startOfMonth(new Date(year, month - 1))
      const endDate = endOfMonth(new Date(year, month - 1))

      const allInvoices = storage.get('INVOICES') || []
      const invoices = []
      if (Array.isArray(allInvoices)) {
        for (let i = 0; i < allInvoices.length; i++) {
          const invDate = new Date(allInvoices[i].invoice_date)
          if (isWithinInterval(invDate, { start: startDate, end: endDate })) {
            invoices.push(allInvoices[i])
          }
        }
      }

      let totalSales = 0
      let totalTax = 0
      for (let i = 0; i < invoices.length; i++) {
        totalSales += (invoices[i].final_total || 0)
        totalTax += (invoices[i].tax_total || 0)
      }

      const allItems = storage.get('INVOICE_ITEMS') || []
      const monthItems = []
      if (Array.isArray(allItems)) {
        for (let i = 0; i < allItems.length; i++) {
          const item = allItems[i]
          let found = false
          for (let j = 0; j < invoices.length; j++) {
            if (invoices[j].id === item.invoice_id) {
              found = true
              break
            }
          }
          if (found) {
            monthItems.push(item)
          }
        }
      }

      const productSales = {}
      const products = storage.get('PRODUCTS') || []

      for (let i = 0; i < monthItems.length; i++) {
        const item = monthItems[i]
        if (!productSales[item.product_id]) {
          let product = null
          for (let j = 0; j < products.length; j++) {
            if (products[j].id === item.product_id) {
              product = products[j]
              break
            }
          }
          productSales[item.product_id] = {
            name: product?.product_name || 'منتج محذوف',
            quantity: 0,
            revenue: 0
          }
        }
        productSales[item.product_id].quantity += item.quantity
        productSales[item.product_id].revenue += item.line_total
      }

      const productSalesArray = []
      for (const key in productSales) {
        productSalesArray.push(productSales[key])
      }
      productSalesArray.sort((a, b) => b.revenue - a.revenue)
      const topProducts = productSalesArray.slice(0, 5)

      const customerSales = {}
      const customers = storage.get('CUSTOMERS') || []

      for (let i = 0; i < invoices.length; i++) {
        const inv = invoices[i]
        if (!customerSales[inv.customer_id]) {
          let customer = null
          for (let j = 0; j < customers.length; j++) {
            if (customers[j].id === inv.customer_id) {
              customer = customers[j]
              break
            }
          }
          customerSales[inv.customer_id] = {
            name: customer?.customer_name || 'عميل محذوف',
            invoiceCount: 0,
            totalSpent: 0
          }
        }
        customerSales[inv.customer_id].invoiceCount++
        customerSales[inv.customer_id].totalSpent += inv.final_total
      }

      const customerSalesArray = []
      for (const key in customerSales) {
        customerSalesArray.push(customerSales[key])
      }
      customerSalesArray.sort((a, b) => b.totalSpent - a.totalSpent)
      const topCustomers = customerSalesArray.slice(0, 5)

      setMonthlyReport({
        month: format(startDate, 'MMMM yyyy', { locale: ar }),
        invoiceCount: invoices.length,
        totalSales,
        totalTax,
        topProducts,
        topCustomers
      })
    } catch (error) {
      console.error('Error generating monthly report:', error)
      setMonthlyReport(null)
    } finally {
      setLoading(false)
    }
  }

  const generateProductReport = () => {
    try {
      setLoading(true)
      const products = storage.get('PRODUCTS') || []
      const allItems = storage.get('INVOICE_ITEMS') || []

      if (!Array.isArray(products) || !Array.isArray(allItems)) {
        setProductReport([])
        return
      }

      const report = []
      for (let i = 0; i < products.length; i++) {
        const product = products[i]
        const productItems = []
        for (let j = 0; j < allItems.length; j++) {
          if (allItems[j].product_id === product.id) {
            productItems.push(allItems[j])
          }
        }

        let totalQuantity = 0
        let totalRevenue = 0
        for (let k = 0; k < productItems.length; k++) {
          totalQuantity += (productItems[k].quantity || 0)
          totalRevenue += (productItems[k].line_total || 0)
        }

        const profit = calculateProfit(product.sale_price, product.cost_price, totalQuantity)

        if (totalQuantity > 0) {
          report.push({
            id: product.id,
            name: product.product_name,
            code: product.product_code,
            totalQuantity,
            totalRevenue,
            profit
          })
        }
      }

      report.sort((a, b) => b.totalRevenue - a.totalRevenue)
      setProductReport(report)
    } catch (error) {
      console.error('Error generating product report:', error)
      setProductReport([])
    } finally {
      setLoading(false)
    }
  }

  const renderTopProducts = () => {
    const items = []
    if (monthlyReport?.topProducts && Array.isArray(monthlyReport.topProducts)) {
      for (let i = 0; i < monthlyReport.topProducts.length; i++) {
        const product = monthlyReport.topProducts[i]
        items.push(
          <div key={i} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
            <div>
              <p className="font-semibold">{product.name}</p>
              <p className="text-sm text-gray-600">الكمية: {product.quantity}</p>
            </div>
            <p className="font-bold text-primary">{formatCurrency(product.revenue)}</p>
          </div>
        )
      }
    }
    return items.length > 0 ? items : (
      <div className="text-center py-8 text-gray-500">لا توجد بيانات</div>
    )
  }

  const renderTopCustomers = () => {
    const items = []
    if (monthlyReport?.topCustomers && Array.isArray(monthlyReport.topCustomers)) {
      for (let i = 0; i < monthlyReport.topCustomers.length; i++) {
        const customer = monthlyReport.topCustomers[i]
        items.push(
          <div key={i} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
            <div>
              <p className="font-semibold">{customer.name}</p>
              <p className="text-sm text-gray-600">عدد الفواتير: {customer.invoiceCount}</p>
            </div>
            <p className="font-bold text-success">{formatCurrency(customer.totalSpent)}</p>
          </div>
        )
      }
    }
    return items.length > 0 ? items : (
      <div className="text-center py-8 text-gray-500">لا توجد بيانات</div>
    )
  }

  const renderProductReportRows = () => {
    const rows = []
    for (let i = 0; i < productReport.length; i++) {
      const product = productReport[i]
      rows.push(
        <motion.tr
          key={product.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.05 }}
          className="border-b hover:bg-gray-50"
        >
          <td className="py-3 px-4">{product.code}</td>
          <td className="py-3 px-4 font-semibold">{product.name}</td>
          <td className="py-3 px-4">{product.totalQuantity}</td>
          <td className="py-3 px-4 font-semibold text-primary">{formatCurrency(product.totalRevenue)}</td>
          <td className="py-3 px-4 font-semibold text-success">{formatCurrency(product.profit)}</td>
        </motion.tr>
      )
    }
    return rows
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-dark mb-6">التقارير</h1>

      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-bold mb-4">تقرير المبيعات اليومية</h2>
        <div className="mb-4">
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
        {dailyReport && (
          <div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-primary/10 rounded-lg p-4">
                <div className="flex items-center gap-3">
                  <TrendingUp className="text-primary" size={24} />
                  <div>
                    <p className="text-sm text-gray-600">عدد الفواتير</p>
                    <p className="text-2xl font-bold">{dailyReport.invoiceCount}</p>
                  </div>
                </div>
              </div>
              <div className="bg-success/10 rounded-lg p-4">
                <div className="flex items-center gap-3">
                  <DollarSign className="text-success" size={24} />
                  <div>
                    <p className="text-sm text-gray-600">إجمالي المبيعات</p>
                    <p className="text-2xl font-bold">{formatCurrency(dailyReport.totalSales)}</p>
                  </div>
                </div>
              </div>
              <div className="bg-warning/10 rounded-lg p-4">
                <div className="flex items-center gap-3">
                  <DollarSign className="text-warning" size={24} />
                  <div>
                    <p className="text-sm text-gray-600">المبيعات النقدية</p>
                    <p className="text-2xl font-bold">{formatCurrency(dailyReport.cashSales)}</p>
                  </div>
                </div>
              </div>
              <div className="bg-danger/10 rounded-lg p-4">
                <div className="flex items-center gap-3">
                  <DollarSign className="text-danger" size={24} />
                  <div>
                    <p className="text-sm text-gray-600">المبيعات الآجلة</p>
                    <p className="text-2xl font-bold">{formatCurrency(dailyReport.creditSales)}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-bold mb-4">تقرير المبيعات الشهرية</h2>
        <div className="mb-4">
          <input
            type="month"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
        {monthlyReport && (
          <div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-primary/10 rounded-lg p-4">
                <p className="text-sm text-gray-600">عدد الفواتير</p>
                <p className="text-2xl font-bold">{monthlyReport.invoiceCount}</p>
              </div>
              <div className="bg-success/10 rounded-lg p-4">
                <p className="text-sm text-gray-600">إجمالي المبيعات</p>
                <p className="text-2xl font-bold">{formatCurrency(monthlyReport.totalSales)}</p>
              </div>
              <div className="bg-warning/10 rounded-lg p-4">
                <p className="text-sm text-gray-600">إجمالي الضرائب</p>
                <p className="text-2xl font-bold">{formatCurrency(monthlyReport.totalTax)}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-bold mb-3">أعلى المنتجات مبيعاً</h3>
                <div className="space-y-2">
                  {renderTopProducts()}
                </div>
              </div>

              <div>
                <h3 className="font-bold mb-3">أعلى العملاء شراءً</h3>
                <div className="space-y-2">
                  {renderTopCustomers()}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-bold mb-4">تقرير مبيعات المنتجات</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="text-right py-3 px-4 font-semibold">كود المنتج</th>
                <th className="text-right py-3 px-4 font-semibold">اسم المنتج</th>
                <th className="text-right py-3 px-4 font-semibold">الكمية المباعة</th>
                <th className="text-right py-3 px-4 font-semibold">الإيرادات</th>
                <th className="text-right py-3 px-4 font-semibold">الربح</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="5" className="py-12 text-center text-gray-500">
                    جاري التحميل...
                  </td>
                </tr>
              ) : productReport.length > 0 ? (
                renderProductReportRows()
              ) : (
                <tr>
                  <td colSpan="5" className="py-12 text-center text-gray-500">
                    لا توجد بيانات
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

export default Reports