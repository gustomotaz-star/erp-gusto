import { useState } from 'react'
import { motion } from 'framer-motion'
import { Download, Upload, FileText, Users, Package } from 'lucide-react'
import Button from '../components/Button'
import Modal from '../components/Modal'
import { storage } from '../utils/storage'
import { exportToCSV, importFromCSV, validateCSVData } from '../utils/csvUtils'

const SettingsImportExport = () => {
  const [modalOpen, setModalOpen] = useState(false)
  const [modalMessage, setModalMessage] = useState('')
  const [modalType, setModalType] = useState('success')
  const [uploading, setUploading] = useState(false)

  const showMessage = (message, type = 'success') => {
    setModalMessage(message)
    setModalType(type)
    setModalOpen(true)
  }

  // توليد كود عميل عند الحاجة
  const generateCustomerCode = () => {
    const customers = storage.get("CUSTOMERS") || [];
    if (customers.length === 0) return "CUST-0001";

    const numbers = customers
      .map(c => parseInt(c.customer_code?.replace("CUST-", "")))
      .filter(n => !isNaN(n));

    const next = Math.max(...numbers, 0) + 1;
    return `CUST-${String(next).padStart(4, "0")}`;
  };

  // إيجاد أو إنشاء عميل حسب الكود
  const getOrCreateCustomerByCode = (customer_code) => {
    let customers = storage.get("CUSTOMERS") || [];

    let existing = customers.find(c => c.customer_code === customer_code);
    if (existing) return existing;

    const newCustomer = {
      id: crypto.randomUUID(),
      customer_code,
      customer_name: customer_code,
      phone: "",
      email: "",
      address: "",
      tax_number: "",
      status: "active"
    };

    customers.push(newCustomer);
    storage.set("CUSTOMERS", customers);
    return newCustomer;
  };

  const handleExport = (dataType) => {
    try {
      let data = []
      let filename = ''
      let headers = []

      switch(dataType) {
        case 'invoices':
          data = storage.get('INVOICES') || []
          filename = 'invoices'
          headers = ['invoice_number','customer_code','invoice_date','payment_type','final_total']
          break

        case 'customers':
          data = storage.get('CUSTOMERS') || []
          filename = 'customers'
          headers = ['customer_code','customer_name','phone','email','address','tax_number','status']
          break

        case 'products':
          data = storage.get('PRODUCTS') || []
          filename = 'products'
          headers = ['product_code','product_name','description','cost_price','sale_price','stock_quantity','min_stock_level','tax1','tax2','status']
          break
      }

      if (data.length === 0) {
        showMessage('لا توجد بيانات للتصدير', 'error')
        return
      }

      exportToCSV(data, filename, headers)
      showMessage(`تم تصدير ${data.length} سجل بنجاح`, 'success')

    } catch (error) {
      showMessage('فشل التصدير: ' + error.message, 'error')
    }
  }

  const handleImport = async (event, dataType) => {
    const file = event.target.files?.[0]
    if (!file) return

    if (!file.name.endsWith('.csv')) {
      showMessage('الرجاء اختيار ملف CSV', 'error')
      event.target.value = ''
      return
    }

    setUploading(true)

    try {
      const data = await importFromCSV(file)

      if (!data || data.length === 0) {
        throw new Error('الملف فارغ أو التنسيق غير صحيح')
      }

      let requiredFields = []
      let storageKey = ''
      let uniqueField = ''

      switch(dataType) {
        case 'invoices':
          requiredFields = ['invoice_number','customer_code','invoice_date','payment_type']
          storageKey = 'INVOICES'
          uniqueField = 'invoice_number'
          break

        case 'customers':
          requiredFields = ['customer_name', 'phone']
          storageKey = 'CUSTOMERS'
          uniqueField = 'phone'
          break

        case 'products':
          requiredFields = ['product_code','product_name','sale_price']
          storageKey = 'PRODUCTS'
          uniqueField = 'product_code'
          break
      }

      const validation = validateCSVData(data, requiredFields)
      if (!validation.valid) {
        throw new Error(`خطأ في الصف ${validation.row}: ${validation.error}`)
      }

      const existingData = storage.get(storageKey) || []
      const uniqueValues = new Set(existingData.map(item => item[uniqueField]))

      let imported = 0
      let duplicates = 0
      const newData = [...existingData]

      if (dataType === 'invoices') {
        for (let row of data) {

          // معالجة final_total بدون trim() نهائياً
          let total = row.final_total;

          if (
            total === undefined ||
            total === null ||
            total === "" ||
            (typeof total === "string" && total.trim() === "") ||
            isNaN(total)
          ) {
            total = 0;
          }

          row.final_total = Number(total);

          const customer = getOrCreateCustomerByCode(row.customer_code)

          if (uniqueValues.has(row.invoice_number)) {
            duplicates++
          } else {
            const newInvoice = {
              id: crypto.randomUUID(),
              invoice_number: row.invoice_number,
              customer_id: customer.id,
              customer_code: row.customer_code,
              invoice_date: row.invoice_date,
              payment_type: row.payment_type,
              final_total: row.final_total
            }

            newData.push(newInvoice)
            uniqueValues.add(row.invoice_number)
            imported++
          }
        }

      } else {
        data.forEach((item) => {
          if (uniqueValues.has(item[uniqueField])) {
            duplicates++
          } else {
            newData.push({
              ...item,
              id: crypto.randomUUID()
            })
            uniqueValues.add(item[uniqueField])
            imported++
          }
        })
      }

      storage.set(storageKey, newData)

      const message =
        duplicates > 0
          ? `تم استيراد ${imported} سجل. تم تجاهل ${duplicates} سجل مكرر`
          : `تم استيراد ${imported} سجل بنجاح`

      showMessage(message, 'success')

      setTimeout(() => window.location.reload(), 1200)

    } catch (error) {
      showMessage('فشل الاستيراد: ' + error.message, 'error')
    }

    finally {
      setUploading(false)
      event.target.value = ''
    }
  }

  const sections = [
    { title: 'الفواتير', icon: FileText, type: 'invoices' },
    { title: 'العملاء', icon: Users, type: 'customers' },
    { title: 'المنتجات', icon: Package, type: 'products' }
  ]

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-6xl mx-auto">

        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h1 className="text-3xl font-bold text-dark mb-2">استيراد وتصدير البيانات</h1>
          <p className="text-gray-600">إدارة بيانات النظام من خلال CSV</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sections.map((section) => {
            const Icon = section.icon
            return (
              <motion.div key={section.type} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="bg-white rounded-lg shadow-sm p-6">

                <div className="flex items-center gap-3 mb-4">
                  <div className="p-3 bg-primary/10 rounded-lg">
                    <Icon className="text-primary" size={24} />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold">{section.title}</h2>
                    <p className="text-sm text-gray-600">{section.description}</p>
                  </div>
                </div>

                <Button
                  variant="primary"
                  className="w-full flex items-center justify-center gap-2"
                  onClick={() => handleExport(section.type)}
                >
                  <Download size={18} />
                  تصدير CSV
                </Button>

                <div className="relative mt-3">
                  <input
                    type="file"
                    accept=".csv"
                    onChange={(e) => handleImport(e, section.type)}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    disabled={uploading}
                  />
                  <Button variant="outline" className="w-full flex items-center justify-center gap-2" disabled={uploading}>
                    <Upload size={18} />
                    {uploading ? 'جاري الاستيراد...' : 'استيراد CSV'}
                  </Button>
                </div>

              </motion.div>
            )
          })}
        </div>

      </motion.div>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={modalType === 'success' ? 'نجاح' : 'خطأ'} size="sm">
        <div className="text-center py-4">
          <p className={`text-lg ${modalType === 'success' ? 'text-success' : 'text-danger'}`}>
            {modalMessage}
          </p>
          <Button className="mt-6" onClick={() => setModalOpen(false)}>حسناً</Button>
        </div>
      </Modal>
    </div>
  )
}

export default SettingsImportExport
