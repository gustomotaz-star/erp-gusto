export const calculateLineTotal = (unitPrice, quantity, discountPercent, tax1, tax2) => {
  const subtotal = unitPrice * quantity
  const discountAmount = subtotal * (discountPercent / 100)
  const afterDiscount = subtotal - discountAmount
  const tax1Amount = afterDiscount * (tax1 / 100)
  const tax2Amount = afterDiscount * (tax2 / 100)
  const lineTotal = afterDiscount + tax1Amount + tax2Amount
  
  return {
    subtotal: parseFloat(subtotal.toFixed(2)),
    discountAmount: parseFloat(discountAmount.toFixed(2)),
    afterDiscount: parseFloat(afterDiscount.toFixed(2)),
    tax1Amount: parseFloat(tax1Amount.toFixed(2)),
    tax2Amount: parseFloat(tax2Amount.toFixed(2)),
    lineTotal: parseFloat(lineTotal.toFixed(2))
  }
}

export const calculateInvoiceTotals = (items, invoiceDiscount = 0) => {
  const totalBeforeDiscount = items.reduce((sum, item) => {
    const calc = calculateLineTotal(
      item.unit_price || 0,
      item.quantity || 0,
      item.discount_percent || 0,
      item.tax1 || 0,
      item.tax2 || 0
    )
    return sum + calc.afterDiscount
  }, 0)

  const taxTotal = items.reduce((sum, item) => {
    const calc = calculateLineTotal(
      item.unit_price || 0,
      item.quantity || 0,
      item.discount_percent || 0,
      item.tax1 || 0,
      item.tax2 || 0
    )
    return sum + calc.tax1Amount + calc.tax2Amount
  }, 0)

  const invoiceDiscountAmount = totalBeforeDiscount * (invoiceDiscount / 100)
  const finalTotal = totalBeforeDiscount - invoiceDiscountAmount + taxTotal

  return {
    totalBeforeDiscount: parseFloat(totalBeforeDiscount.toFixed(2)),
    invoiceDiscountAmount: parseFloat(invoiceDiscountAmount.toFixed(2)),
    taxTotal: parseFloat(taxTotal.toFixed(2)),
    finalTotal: parseFloat(finalTotal.toFixed(2))
  }
}

export const calculateProfit = (salePrice, costPrice, quantity) => {
  return (salePrice - costPrice) * quantity
}

export const getInvoiceStatus = (finalTotal, paidAmount) => {
  if (paidAmount >= finalTotal) return 'paid'
  if (paidAmount > 0) return 'partial'
  return 'unpaid'
}

export const formatCurrency = (amount) => {
  return new Intl.NumberFormat('ar-SA', {
    style: 'currency',
    currency: 'SAR'
  }).format(amount)
}