const STORAGE_KEYS = {
  PRODUCTS: 'products',
  CUSTOMERS: 'customers',
  INVOICES: 'invoices',
  INVOICE_ITEMS: 'invoice_items',
  PAYMENTS: 'payments'
}

export const storage = {
  get: (key) => {
    try {
      const item = localStorage.getItem(STORAGE_KEYS[key])
      if (!item) return []
      const parsed = JSON.parse(item)
      return Array.isArray(parsed) ? parsed : []
    } catch (error) {
      console.error(`Error reading ${key}:`, error)
      return []
    }
  },
  set: (key, data) => {
    try {
      localStorage.setItem(STORAGE_KEYS[key], JSON.stringify(data))
      return true
    } catch (error) {
      console.error(`Error saving ${key}:`, error)
      return false
    }
  },
  add: (key, item) => {
    try {
      const items = storage.get(key)
      const newItem = { ...item, id: Date.now().toString() }
      items.push(newItem)
      storage.set(key, items)
      return newItem
    } catch (error) {
      console.error(`Error adding to ${key}:`, error)
      return null
    }
  },
  update: (key, id, updates) => {
    try {
      const items = storage.get(key)
      if (!Array.isArray(items)) return null
      const index = items.findIndex(item => item.id === id)
      if (index !== -1) {
        items[index] = { ...items[index], ...updates }
        storage.set(key, items)
        return items[index]
      }
      return null
    } catch (error) {
      console.error(`Error updating ${key}:`, error)
      return null
    }
  },
  delete: (key, id) => {
    try {
      const items = storage.get(key)
      if (!Array.isArray(items)) return []
      const filtered = []
      for (let i = 0; i < items.length; i++) {
        if (items[i].id !== id) {
          filtered.push(items[i])
        }
      }
      storage.set(key, filtered)
      return filtered
    } catch (error) {
      console.error(`Error deleting from ${key}:`, error)
      return []
    }
  },
  getById: (key, id) => {
    try {
      const items = storage.get(key)
      if (!Array.isArray(items)) return null
      return items.find(item => item.id === id) || null
    } catch (error) {
      console.error(`Error getting by ID from ${key}:`, error)
      return null
    }
  },
  clear: (key) => {
    localStorage.removeItem(STORAGE_KEYS[key])
  }
}

export const generateInvoiceNumber = () => {
  try {
    const invoices = storage.get('INVOICES') || []
    if (!Array.isArray(invoices) || invoices.length === 0) {
      return 'INV-00001'
    }
    const numbers = []
    for (let i = 0; i < invoices.length; i++) {
      const num = parseInt(invoices[i].invoice_number?.replace('INV-', '') || 0)
      numbers.push(num)
    }
    const lastNumber = Math.max(...numbers)
    return `INV-${String(lastNumber + 1).padStart(5, '0')}`
  } catch (error) {
    console.error('Error generating invoice number:', error)
    return 'INV-00001'
  }
}

export const updateInventory = (productId, quantity) => {
  try {
    const product = storage.getById('PRODUCTS', productId)
    if (product) {
      const newQuantity = (product.stock_quantity || 0) - quantity
      storage.update('PRODUCTS', productId, { stock_quantity: newQuantity })
    }
  } catch (error) {
    console.error('Error updating inventory:', error)
  }
}

export const getLowStockProducts = () => {
  try {
    const products = storage.get('PRODUCTS') || []
    if (!Array.isArray(products)) return []
    const lowStock = []
    for (let i = 0; i < products.length; i++) {
      const p = products[i]
      if (p.status === 'active' && p.stock_quantity <= p.min_stock_level) {
        lowStock.push(p)
      }
    }
    return lowStock
  } catch (error) {
    console.error('Error getting low stock products:', error)
    return []
  }
}

export const saveToStorage = (key, value) => {
  try {
    localStorage.setItem(key, JSON.stringify(value))
    return true
  } catch (error) {
    console.error(`Error saving ${key}:`, error)
    return false
  }
}

export const getFromStorage = (key) => {
  try {
    const item = localStorage.getItem(key)
    if (item === null) return null
    return JSON.parse(item)
  } catch (error) {
    console.error(`Error reading ${key}:`, error)
    return null
  }
}

export const clearAllData = () => {
  try {
    const keys = Object.values(STORAGE_KEYS)
    for (let i = 0; i < keys.length; i++) {
      localStorage.removeItem(keys[i])
    }

    const settingsKeys = [
      'businessName', 'userEmail', 'userPhone', 'userAddress',
      'currency', 'taxRate1', 'taxRate2', 'invoicePrefix', 'lowStockThreshold',
      'emailNotifications', 'lowStockAlerts', 'paymentReminders', 'invoiceAlerts',
      'theme', 'language', 'dateFormat', 'numberFormat'
    ]
    for (let i = 0; i < settingsKeys.length; i++) {
      localStorage.removeItem(settingsKeys[i])
    }

    return true
  } catch (error) {
    console.error('Error clearing data:', error)
    return false
  }
}

export const exportData = () => {
  try {
    const data = {}
    const keys = Object.values(STORAGE_KEYS)
    for (let i = 0; i < keys.length; i++) {
      const key = keys[i]
      const storageData = storage.get(key.toUpperCase())
      data[key] = Array.isArray(storageData) ? storageData : []
    }

    const settingsKeys = [
      'businessName', 'userEmail', 'userPhone', 'userAddress',
      'currency', 'taxRate1', 'taxRate2', 'invoicePrefix', 'lowStockThreshold',
      'emailNotifications', 'lowStockAlerts', 'paymentReminders', 'invoiceAlerts',
      'theme', 'language', 'dateFormat', 'numberFormat'
    ]
    const settings = {}
    for (let i = 0; i < settingsKeys.length; i++) {
      const key = settingsKeys[i]
      const value = getFromStorage(key)
      if (value !== null) settings[key] = value
    }
    data.settings = settings

    return JSON.stringify(data, null, 2)
  } catch (error) {
    console.error('Error exporting data:', error)
    return null
  }
}

export const importData = (jsonString) => {
  try {
    const data = JSON.parse(jsonString)
    if (!data || typeof data !== 'object') {
      throw new Error('Invalid data format')
    }

    const keys = Object.values(STORAGE_KEYS)
    for (let i = 0; i < keys.length; i++) {
      const key = keys[i]
      if (data[key] && Array.isArray(data[key])) {
        storage.set(key.toUpperCase(), data[key])
      }
    }

    if (data.settings) {
      const settingKeys = Object.keys(data.settings)
      for (let i = 0; i < settingKeys.length; i++) {
        const key = settingKeys[i]
        saveToStorage(key, data.settings[key])
      }
    }

    return true
  } catch (error) {
    console.error('Error importing data:', error)
    return false
  }
}