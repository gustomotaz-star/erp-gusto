export const exportToCSV = (data, filename, headers) => {
  if (!data || data.length === 0) {
    throw new Error('لا توجد بيانات للتصدير')
  }

  const csvHeaders = headers || Object.keys(data[0])
  const csvRows = []

  csvRows.push(csvHeaders.join(','))

  data.forEach(item => {
    const values = csvHeaders.map(header => {
      const value = item[header] ?? ''   // دعم null و undefined
      const escaped = String(value).replace(/"/g, '""')
      return `"${escaped}"`
    })
    csvRows.push(values.join(','))
  })

  const csvContent = csvRows.join('\n')
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
  const link = document.createElement('a')
  const url = URL.createObjectURL(blob)
  
  link.setAttribute('href', url)
  link.setAttribute('download', `${filename}_${new Date().toISOString().split('T')[0]}.csv`)
  link.style.visibility = 'hidden'
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}

export const importFromCSV = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    
    reader.onload = (event) => {
      try {
        const text = event.target.result
        const lines = text.split('\n').filter(line => line.trim().length > 0)
        
        if (lines.length < 2) {
          reject(new Error('الملف فارغ أو تنسيقه غير صحيح'))
          return
        }

        const headers = lines[0]
          .split(',')
          .map(h => h.trim().replace(/^"|"$/g, ''))

        const data = []

        for (let i = 1; i < lines.length; i++) {
          const parsed = parseCSVLine(lines[i])
          
          if (parsed.length !== headers.length) continue

          const row = {}

          headers.forEach((header, index) => {
            let value = parsed[index]
            if (value == null) value = ""

            // إزالة العلامات "" من البداية والنهاية
            value = String(value).trim().replace(/^"|"$/g, '').replace(/""/g, '"')

            // تحويل القيم
            if (value === "") {
              row[header] = null
            } 
            else if (!isNaN(value)) {
              row[header] = Number(value)  // رقم
            } 
            else {
              row[header] = value          // نص
            }
          })

          data.push(row)
        }

        resolve(data)

      } catch (error) {
        reject(new Error('فشل قراءة الملف: ' + error.message))
      }
    }

    reader.onerror = () => reject(new Error('فشل قراءة الملف'))

    reader.readAsText(file, 'UTF-8')
  })
}

const parseCSVLine = (line) => {
  const values = []
  let current = ''
  let inQuotes = false

  for (let i = 0; i < line.length; i++) {
    const char = line[i]
    const nextChar = line[i + 1]

    if (char === '"' && inQuotes && nextChar === '"') {
      current += '"'
      i++
    } else if (char === '"') {
      inQuotes = !inQuotes
    } else if (char === ',' && !inQuotes) {
      values.push(current)
      current = ''
    } else {
      current += char
    }
  }

  values.push(current)
  return values
}

// ======== النسخة النهائية المحسّنة لدالة التحقق ========
// تدعم: null، رقم، نص، undefined، وتتعامل بدون toLowerCase
export const validateCSVData = (data, requiredFields) => {
  for (let i = 0; i < data.length; i++) {
    const row = data[i]

    for (let field of requiredFields) {

      let value = row[field]

      // null أو undefined أو قيمة غير موجودة
      if (value === undefined || value === null) {
        return {
          valid: false,
          row: i + 2,
          error: `الحقل "${field}" مطلوب`
        }
      }

      // تحويل القيمة إلى نص
      const strValue = String(value).trim()

      if (strValue === "") {
        return {
          valid: false,
          row: i + 2,
          error: `الحقل "${field}" لا يمكن أن يكون فارغاً`
        }
      }
    }
  }

  return { valid: true }
}
