import { Link, useLocation } from 'react-router-dom'
import { LayoutDashboard, Package, Users, FileText, CreditCard, BarChart3, Settings, Download } from 'lucide-react'
import { motion } from 'framer-motion'

const Sidebar = () => {
  const location = useLocation()

  const menuItems = [
    { path: '/dashboard', icon: LayoutDashboard, label: 'لوحة التحكم' },
    { path: '/products', icon: Package, label: 'المنتجات' },
    { path: '/customers', icon: Users, label: 'العملاء' },
    { path: '/invoices', icon: FileText, label: 'الفواتير' },
    { path: '/payments', icon: CreditCard, label: 'المدفوعات' },
    { path: '/reports', icon: BarChart3, label: 'التقارير' },
    { path: '/settings', icon: Settings, label: 'الإعدادات' },
    { path: '/settings-import-export', icon: Download, label: 'استيراد وتصدير' }
  ]

  return (
    <div className="w-64 bg-dark text-white h-screen sticky top-0">
      <div className="p-6 border-b border-gray-700">
        <h1 className="text-2xl font-bold">نظام المبيعات</h1>
        <p className="text-sm text-gray-400 mt-1">إدارة المخزون</p>
      </div>
      <nav className="p-4">
        {menuItems.map((item) => {
          const Icon = item.icon
          const isActive = location.pathname.startsWith(item.path)
          return (
            <Link key={item.path} to={item.path}>
              <motion.div
                whileHover={{ x: -5 }}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg mb-2 transition-colors ${
                  isActive
                    ? 'bg-primary text-white'
                    : 'hover:bg-gray-800 text-gray-300'
                }`}
              >
                <Icon size={20} />
                <span className="font-semibold">{item.label}</span>
              </motion.div>
            </Link>
          )
        })}
      </nav>
    </div>
  )
}

export default Sidebar