import { motion } from 'framer-motion'

const Button = ({ children, variant = 'primary', size = 'md', onClick, type = 'button', disabled, className = '' }) => {
  const variants = {
    primary: 'bg-primary hover:bg-blue-700 text-white',
    secondary: 'bg-secondary hover:bg-blue-300 text-dark',
    success: 'bg-success hover:bg-green-700 text-white',
    danger: 'bg-danger hover:bg-red-700 text-white',
    outline: 'border-2 border-primary text-primary hover:bg-primary hover:text-white'
  }

  const sizes = {
    sm: 'px-3 py-1.5 text-sm',
    md: 'px-4 py-2',
    lg: 'px-6 py-3 text-lg'
  }

  return (
    <motion.button
      whileHover={{ scale: disabled ? 1 : 1.02 }}
      whileTap={{ scale: disabled ? 1 : 0.98 }}
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`${variants[variant]} ${sizes[size]} rounded-lg font-cairo font-semibold transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
    >
      {children}
    </motion.button>
  )
}

export default Button