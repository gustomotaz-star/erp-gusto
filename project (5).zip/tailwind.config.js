export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#0052CC',
        secondary: '#A5D8FF',
        success: '#2F9E44',
        danger: '#FF6B6B',
        warning: '#FF9700',
        dark: '#1A1A1A',
        light: '#F5F7FA'
      },
      fontFamily: {
        cairo: ['Cairo', 'sans-serif']
      }
    }
  },
  plugins: []
}